function [data, info] = clockRequest
%Clock gives an empty data for interfaces/ClockRequest
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'interfaces/ClockRequest';
[data.request_value, info.request_value] = ros.internal.ros2.messages.ros2.default_type('uint8',1,0);
info.MessageType = 'interfaces/ClockRequest';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,1);
info.MatPath{1} = 'request_value';
