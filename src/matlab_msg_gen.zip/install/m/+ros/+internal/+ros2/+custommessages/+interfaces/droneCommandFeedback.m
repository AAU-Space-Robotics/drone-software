function [data, info] = droneCommandFeedback
%DroneCommandFeedback gives an empty data for interfaces/DroneCommandFeedback
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'interfaces/DroneCommandFeedback';
[data.current_pose, info.current_pose] = ros.internal.ros2.messages.ros2.default_type('double',NaN,0);
[data.current_yaw, info.current_yaw] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
info.MessageType = 'interfaces/DroneCommandFeedback';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,2);
info.MatPath{1} = 'current_pose';
info.MatPath{2} = 'current_yaw';
