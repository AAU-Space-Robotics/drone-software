function [data, info] = probeSegmentation
%ProbeSegmentation gives an empty data for interfaces/ProbeSegmentation
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'interfaces/ProbeSegmentation';
[data.id, info.id] = ros.internal.ros2.messages.ros2.default_type('uint32',1,0);
[data.class_name, info.class_name] = ros.internal.ros2.messages.ros2.char('string',1,NaN,0);
[data.confidence, info.confidence] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.box, info.box] = ros.internal.ros2.messages.ros2.default_type('single',NaN,0);
[data.mask, info.mask] = ros.internal.ros2.messages.ros2.default_type('single',NaN,0);
[data.mask_width, info.mask_width] = ros.internal.ros2.messages.ros2.default_type('uint32',1,0);
[data.mask_height, info.mask_height] = ros.internal.ros2.messages.ros2.default_type('uint32',1,0);
info.MessageType = 'interfaces/ProbeSegmentation';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,7);
info.MatPath{1} = 'id';
info.MatPath{2} = 'class_name';
info.MatPath{3} = 'confidence';
info.MatPath{4} = 'box';
info.MatPath{5} = 'mask';
info.MatPath{6} = 'mask_width';
info.MatPath{7} = 'mask_height';
