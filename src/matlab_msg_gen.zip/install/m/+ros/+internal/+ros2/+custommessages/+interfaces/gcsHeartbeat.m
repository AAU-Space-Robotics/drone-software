function [data, info] = gcsHeartbeat
%GcsHeartbeat gives an empty data for interfaces/GcsHeartbeat
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'interfaces/GcsHeartbeat';
[data.timestamp, info.timestamp] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.gcs_nominal, info.gcs_nominal] = ros.internal.ros2.messages.ros2.default_type('int8',1,0);
info.MessageType = 'interfaces/GcsHeartbeat';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,2);
info.MatPath{1} = 'timestamp';
info.MatPath{2} = 'gcs_nominal';
