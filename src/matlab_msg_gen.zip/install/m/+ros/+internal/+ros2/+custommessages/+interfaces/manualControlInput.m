function [data, info] = manualControlInput
%ManualControlInput gives an empty data for interfaces/ManualControlInput
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'interfaces/ManualControlInput';
[data.roll, info.roll] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.pitch, info.pitch] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.yaw_velocity, info.yaw_velocity] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.thrust, info.thrust] = ros.internal.ros2.messages.ros2.default_type('single',1,0);
[data.arm, info.arm] = ros.internal.ros2.messages.ros2.default_type('uint8',1,0);
[data.estop, info.estop] = ros.internal.ros2.messages.ros2.default_type('uint8',1,0);
[data.selfdestruct, info.selfdestruct] = ros.internal.ros2.messages.ros2.default_type('uint8',1,0);
info.MessageType = 'interfaces/ManualControlInput';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,7);
info.MatPath{1} = 'roll';
info.MatPath{2} = 'pitch';
info.MatPath{3} = 'yaw_velocity';
info.MatPath{4} = 'thrust';
info.MatPath{5} = 'arm';
info.MatPath{6} = 'estop';
info.MatPath{7} = 'selfdestruct';
