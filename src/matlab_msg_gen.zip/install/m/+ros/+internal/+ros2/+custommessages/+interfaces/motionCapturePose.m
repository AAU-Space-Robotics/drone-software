function [data, info] = motionCapturePose
%MotionCapturePose gives an empty data for interfaces/MotionCapturePose
% Copyright 2019-2021 The MathWorks, Inc.
data = struct();
data.MessageType = 'interfaces/MotionCapturePose';
[data.timestamp, info.timestamp] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.x, info.x] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.y, info.y] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.z, info.z] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.roll, info.roll] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.pitch, info.pitch] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
[data.yaw, info.yaw] = ros.internal.ros2.messages.ros2.default_type('double',1,0);
info.MessageType = 'interfaces/MotionCapturePose';
info.constant = 0;
info.default = 0;
info.maxstrlen = NaN;
info.MaxLen = 1;
info.MinLen = 1;
info.MatPath = cell(1,7);
info.MatPath{1} = 'timestamp';
info.MatPath{2} = 'x';
info.MatPath{3} = 'y';
info.MatPath{4} = 'z';
info.MatPath{5} = 'roll';
info.MatPath{6} = 'pitch';
info.MatPath{7} = 'yaw';
