// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:srv/Clock.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__CLOCK_H_
#define INTERFACES__SRV__CLOCK_H_

#include "interfaces/srv/detail/clock__struct.h"
#include "interfaces/srv/detail/clock__functions.h"
#include "interfaces/srv/detail/clock__type_support.h"

#endif  // INTERFACES__SRV__CLOCK_H_
