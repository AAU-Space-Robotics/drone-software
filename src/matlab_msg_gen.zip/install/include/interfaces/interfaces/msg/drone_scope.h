// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:msg/DroneScope.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DRONE_SCOPE_H_
#define INTERFACES__MSG__DRONE_SCOPE_H_

#include "interfaces/msg/detail/drone_scope__struct.h"
#include "interfaces/msg/detail/drone_scope__functions.h"
#include "interfaces/msg/detail/drone_scope__type_support.h"

#endif  // INTERFACES__MSG__DRONE_SCOPE_H_
