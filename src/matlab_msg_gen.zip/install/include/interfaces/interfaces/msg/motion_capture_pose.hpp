// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__MOTION_CAPTURE_POSE_HPP_
#define INTERFACES__MSG__MOTION_CAPTURE_POSE_HPP_

#include "interfaces/msg/detail/motion_capture_pose__struct.hpp"
#include "interfaces/msg/detail/motion_capture_pose__builder.hpp"
#include "interfaces/msg/detail/motion_capture_pose__traits.hpp"
#include "interfaces/msg/detail/motion_capture_pose__type_support.hpp"

#endif  // INTERFACES__MSG__MOTION_CAPTURE_POSE_HPP_
