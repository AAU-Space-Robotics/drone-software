// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:msg/MotionCapturePose.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__MOTION_CAPTURE_POSE_H_
#define INTERFACES__MSG__MOTION_CAPTURE_POSE_H_

#include "interfaces/msg/detail/motion_capture_pose__struct.h"
#include "interfaces/msg/detail/motion_capture_pose__functions.h"
#include "interfaces/msg/detail/motion_capture_pose__type_support.h"

#endif  // INTERFACES__MSG__MOTION_CAPTURE_POSE_H_
