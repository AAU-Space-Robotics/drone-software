// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:msg/ProbeLocations.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__PROBE_LOCATIONS_H_
#define INTERFACES__MSG__PROBE_LOCATIONS_H_

#include "interfaces/msg/detail/probe_locations__struct.h"
#include "interfaces/msg/detail/probe_locations__functions.h"
#include "interfaces/msg/detail/probe_locations__type_support.h"

#endif  // INTERFACES__MSG__PROBE_LOCATIONS_H_
