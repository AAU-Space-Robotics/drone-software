// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__MANUAL_CONTROL_INPUT_HPP_
#define INTERFACES__MSG__MANUAL_CONTROL_INPUT_HPP_

#include "interfaces/msg/detail/manual_control_input__struct.hpp"
#include "interfaces/msg/detail/manual_control_input__builder.hpp"
#include "interfaces/msg/detail/manual_control_input__traits.hpp"
#include "interfaces/msg/detail/manual_control_input__type_support.hpp"

#endif  // INTERFACES__MSG__MANUAL_CONTROL_INPUT_HPP_
