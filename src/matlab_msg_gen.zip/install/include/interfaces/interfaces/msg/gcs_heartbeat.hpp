// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__GCS_HEARTBEAT_HPP_
#define INTERFACES__MSG__GCS_HEARTBEAT_HPP_

#include "interfaces/msg/detail/gcs_heartbeat__struct.hpp"
#include "interfaces/msg/detail/gcs_heartbeat__builder.hpp"
#include "interfaces/msg/detail/gcs_heartbeat__traits.hpp"
#include "interfaces/msg/detail/gcs_heartbeat__type_support.hpp"

#endif  // INTERFACES__MSG__GCS_HEARTBEAT_HPP_
