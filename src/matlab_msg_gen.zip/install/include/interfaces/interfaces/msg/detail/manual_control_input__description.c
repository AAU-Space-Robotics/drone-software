// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from interfaces:msg/ManualControlInput.idl
// generated code does not contain a copyright notice

#include "interfaces/msg/detail/manual_control_input__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_interfaces
const rosidl_type_hash_t *
interfaces__msg__ManualControlInput__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x22, 0xd6, 0x24, 0xda, 0x3e, 0x99, 0x19, 0x9d,
      0x53, 0x79, 0xff, 0x99, 0xba, 0x49, 0x75, 0xaa,
      0x79, 0x59, 0xa6, 0xba, 0xf8, 0x07, 0xc1, 0xb8,
      0x51, 0x73, 0xe2, 0x21, 0xaf, 0x83, 0x88, 0x9e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char interfaces__msg__ManualControlInput__TYPE_NAME[] = "interfaces/msg/ManualControlInput";

// Define type names, field names, and default values
static char interfaces__msg__ManualControlInput__FIELD_NAME__roll[] = "roll";
static char interfaces__msg__ManualControlInput__FIELD_NAME__pitch[] = "pitch";
static char interfaces__msg__ManualControlInput__FIELD_NAME__yaw_velocity[] = "yaw_velocity";
static char interfaces__msg__ManualControlInput__FIELD_NAME__thrust[] = "thrust";
static char interfaces__msg__ManualControlInput__FIELD_NAME__arm[] = "arm";
static char interfaces__msg__ManualControlInput__FIELD_NAME__estop[] = "estop";
static char interfaces__msg__ManualControlInput__FIELD_NAME__selfdestruct[] = "selfdestruct";

static rosidl_runtime_c__type_description__Field interfaces__msg__ManualControlInput__FIELDS[] = {
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__roll, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__pitch, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__yaw_velocity, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__thrust, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__arm, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__estop, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ManualControlInput__FIELD_NAME__selfdestruct, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
interfaces__msg__ManualControlInput__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {interfaces__msg__ManualControlInput__TYPE_NAME, 33, 33},
      {interfaces__msg__ManualControlInput__FIELDS, 7, 7},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32 roll         # Left stick X-axis\n"
  "float32 pitch        # Left stick Y-axis (inverted for correct mapping)\n"
  "float32 yaw_velocity # Right stick X-axis\n"
  "float32 thrust       # Right stick Y-axis, mapped from [-1,1] to [0,1]\n"
  "uint8 arm            # 0 when not armed and 1 when armed\n"
  "uint8 estop          # inactive when 0 and active when 1\n"
  "uint8 selfdestruct   #yeps";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
interfaces__msg__ManualControlInput__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {interfaces__msg__ManualControlInput__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 367, 367},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
interfaces__msg__ManualControlInput__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *interfaces__msg__ManualControlInput__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
