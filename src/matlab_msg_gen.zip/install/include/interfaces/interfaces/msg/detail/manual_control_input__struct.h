// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/ManualControlInput.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/manual_control_input.h"


#ifndef INTERFACES__MSG__DETAIL__MANUAL_CONTROL_INPUT__STRUCT_H_
#define INTERFACES__MSG__DETAIL__MANUAL_CONTROL_INPUT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ManualControlInput in the package interfaces.
typedef struct interfaces__msg__ManualControlInput
{
  /// Left stick X-axis
  float roll;
  /// Left stick Y-axis (inverted for correct mapping)
  float pitch;
  /// Right stick X-axis
  float yaw_velocity;
  /// Right stick Y-axis, mapped from [-1,1] to [0,1]
  float thrust;
  /// 0 when not armed and 1 when armed
  uint8_t arm;
  /// inactive when 0 and active when 1
  uint8_t estop;
  /// yeps
  uint8_t selfdestruct;
} interfaces__msg__ManualControlInput;

// Struct for a sequence of interfaces__msg__ManualControlInput.
typedef struct interfaces__msg__ManualControlInput__Sequence
{
  interfaces__msg__ManualControlInput * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__ManualControlInput__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__MANUAL_CONTROL_INPUT__STRUCT_H_
