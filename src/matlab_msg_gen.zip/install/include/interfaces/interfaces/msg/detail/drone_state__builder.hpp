// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_state.hpp"


#ifndef INTERFACES__MSG__DETAIL__DRONE_STATE__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__DRONE_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/drone_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_DroneState_flight_time
{
public:
  explicit Init_DroneState_flight_time(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::DroneState flight_time(::interfaces::msg::DroneState::_flight_time_type arg)
  {
    msg_.flight_time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_flight_mode
{
public:
  explicit Init_DroneState_flight_mode(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_flight_time flight_mode(::interfaces::msg::DroneState::_flight_mode_type arg)
  {
    msg_.flight_mode = std::move(arg);
    return Init_DroneState_flight_time(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_estop
{
public:
  explicit Init_DroneState_estop(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_flight_mode estop(::interfaces::msg::DroneState::_estop_type arg)
  {
    msg_.estop = std::move(arg);
    return Init_DroneState_flight_mode(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_probes_found
{
public:
  explicit Init_DroneState_probes_found(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_estop probes_found(::interfaces::msg::DroneState::_probes_found_type arg)
  {
    msg_.probes_found = std::move(arg);
    return Init_DroneState_estop(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_trajectory_mode
{
public:
  explicit Init_DroneState_trajectory_mode(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_probes_found trajectory_mode(::interfaces::msg::DroneState::_trajectory_mode_type arg)
  {
    msg_.trajectory_mode = std::move(arg);
    return Init_DroneState_probes_found(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_arming_state
{
public:
  explicit Init_DroneState_arming_state(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_trajectory_mode arming_state(::interfaces::msg::DroneState::_arming_state_type arg)
  {
    msg_.arming_state = std::move(arg);
    return Init_DroneState_trajectory_mode(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_actuator_speeds
{
public:
  explicit Init_DroneState_actuator_speeds(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_arming_state actuator_speeds(::interfaces::msg::DroneState::_actuator_speeds_type arg)
  {
    msg_.actuator_speeds = std::move(arg);
    return Init_DroneState_arming_state(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_battery_average_current
{
public:
  explicit Init_DroneState_battery_average_current(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_actuator_speeds battery_average_current(::interfaces::msg::DroneState::_battery_average_current_type arg)
  {
    msg_.battery_average_current = std::move(arg);
    return Init_DroneState_actuator_speeds(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_battery_discharged_mah
{
public:
  explicit Init_DroneState_battery_discharged_mah(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_battery_average_current battery_discharged_mah(::interfaces::msg::DroneState::_battery_discharged_mah_type arg)
  {
    msg_.battery_discharged_mah = std::move(arg);
    return Init_DroneState_battery_average_current(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_battery_percentage
{
public:
  explicit Init_DroneState_battery_percentage(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_battery_discharged_mah battery_percentage(::interfaces::msg::DroneState::_battery_percentage_type arg)
  {
    msg_.battery_percentage = std::move(arg);
    return Init_DroneState_battery_discharged_mah(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_battery_current
{
public:
  explicit Init_DroneState_battery_current(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_battery_percentage battery_current(::interfaces::msg::DroneState::_battery_current_type arg)
  {
    msg_.battery_current = std::move(arg);
    return Init_DroneState_battery_percentage(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_battery_voltage
{
public:
  explicit Init_DroneState_battery_voltage(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_battery_current battery_voltage(::interfaces::msg::DroneState::_battery_voltage_type arg)
  {
    msg_.battery_voltage = std::move(arg);
    return Init_DroneState_battery_current(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_battery_state_timestamp
{
public:
  explicit Init_DroneState_battery_state_timestamp(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_battery_voltage battery_state_timestamp(::interfaces::msg::DroneState::_battery_state_timestamp_type arg)
  {
    msg_.battery_state_timestamp = std::move(arg);
    return Init_DroneState_battery_voltage(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_acceleration
{
public:
  explicit Init_DroneState_acceleration(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_battery_state_timestamp acceleration(::interfaces::msg::DroneState::_acceleration_type arg)
  {
    msg_.acceleration = std::move(arg);
    return Init_DroneState_battery_state_timestamp(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_target_position
{
public:
  explicit Init_DroneState_target_position(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_acceleration target_position(::interfaces::msg::DroneState::_target_position_type arg)
  {
    msg_.target_position = std::move(arg);
    return Init_DroneState_acceleration(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_orientation
{
public:
  explicit Init_DroneState_orientation(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_target_position orientation(::interfaces::msg::DroneState::_orientation_type arg)
  {
    msg_.orientation = std::move(arg);
    return Init_DroneState_target_position(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_velocity
{
public:
  explicit Init_DroneState_velocity(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_orientation velocity(::interfaces::msg::DroneState::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_DroneState_orientation(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_velocity_timestamp
{
public:
  explicit Init_DroneState_velocity_timestamp(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_velocity velocity_timestamp(::interfaces::msg::DroneState::_velocity_timestamp_type arg)
  {
    msg_.velocity_timestamp = std::move(arg);
    return Init_DroneState_velocity(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_position
{
public:
  explicit Init_DroneState_position(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_velocity_timestamp position(::interfaces::msg::DroneState::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_DroneState_velocity_timestamp(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_position_timestamp
{
public:
  explicit Init_DroneState_position_timestamp(::interfaces::msg::DroneState & msg)
  : msg_(msg)
  {}
  Init_DroneState_position position_timestamp(::interfaces::msg::DroneState::_position_timestamp_type arg)
  {
    msg_.position_timestamp = std::move(arg);
    return Init_DroneState_position(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

class Init_DroneState_timestamp
{
public:
  Init_DroneState_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DroneState_position_timestamp timestamp(::interfaces::msg::DroneState::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_DroneState_position_timestamp(msg_);
  }

private:
  ::interfaces::msg::DroneState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::DroneState>()
{
  return interfaces::msg::builder::Init_DroneState_timestamp();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__DRONE_STATE__BUILDER_HPP_
