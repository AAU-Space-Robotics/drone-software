// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/DroneCommand.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_command.hpp"


#ifndef INTERFACES__MSG__DETAIL__DRONE_COMMAND__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__DRONE_COMMAND__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/drone_command__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_DroneCommand_cmd_auto_disarm
{
public:
  explicit Init_DroneCommand_cmd_auto_disarm(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::DroneCommand cmd_auto_disarm(::interfaces::msg::DroneCommand::_cmd_auto_disarm_type arg)
  {
    msg_.cmd_auto_disarm = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_auto_thrust
{
public:
  explicit Init_DroneCommand_cmd_auto_thrust(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_auto_disarm cmd_auto_thrust(::interfaces::msg::DroneCommand::_cmd_auto_thrust_type arg)
  {
    msg_.cmd_auto_thrust = std::move(arg);
    return Init_DroneCommand_cmd_auto_disarm(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_auto_yaw
{
public:
  explicit Init_DroneCommand_cmd_auto_yaw(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_auto_thrust cmd_auto_yaw(::interfaces::msg::DroneCommand::_cmd_auto_yaw_type arg)
  {
    msg_.cmd_auto_yaw = std::move(arg);
    return Init_DroneCommand_cmd_auto_thrust(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_auto_pitch
{
public:
  explicit Init_DroneCommand_cmd_auto_pitch(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_auto_yaw cmd_auto_pitch(::interfaces::msg::DroneCommand::_cmd_auto_pitch_type arg)
  {
    msg_.cmd_auto_pitch = std::move(arg);
    return Init_DroneCommand_cmd_auto_yaw(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_auto_roll
{
public:
  explicit Init_DroneCommand_cmd_auto_roll(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_auto_pitch cmd_auto_roll(::interfaces::msg::DroneCommand::_cmd_auto_roll_type arg)
  {
    msg_.cmd_auto_roll = std::move(arg);
    return Init_DroneCommand_cmd_auto_pitch(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_thrust
{
public:
  explicit Init_DroneCommand_cmd_thrust(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_auto_roll cmd_thrust(::interfaces::msg::DroneCommand::_cmd_thrust_type arg)
  {
    msg_.cmd_thrust = std::move(arg);
    return Init_DroneCommand_cmd_auto_roll(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_yaw
{
public:
  explicit Init_DroneCommand_cmd_yaw(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_thrust cmd_yaw(::interfaces::msg::DroneCommand::_cmd_yaw_type arg)
  {
    msg_.cmd_yaw = std::move(arg);
    return Init_DroneCommand_cmd_thrust(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_pitch
{
public:
  explicit Init_DroneCommand_cmd_pitch(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_yaw cmd_pitch(::interfaces::msg::DroneCommand::_cmd_pitch_type arg)
  {
    msg_.cmd_pitch = std::move(arg);
    return Init_DroneCommand_cmd_yaw(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_roll
{
public:
  explicit Init_DroneCommand_cmd_roll(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_pitch cmd_roll(::interfaces::msg::DroneCommand::_cmd_roll_type arg)
  {
    msg_.cmd_roll = std::move(arg);
    return Init_DroneCommand_cmd_pitch(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_mode
{
public:
  explicit Init_DroneCommand_cmd_mode(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_roll cmd_mode(::interfaces::msg::DroneCommand::_cmd_mode_type arg)
  {
    msg_.cmd_mode = std::move(arg);
    return Init_DroneCommand_cmd_roll(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_arm
{
public:
  explicit Init_DroneCommand_cmd_arm(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_mode cmd_arm(::interfaces::msg::DroneCommand::_cmd_arm_type arg)
  {
    msg_.cmd_arm = std::move(arg);
    return Init_DroneCommand_cmd_mode(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_identifier
{
public:
  explicit Init_DroneCommand_identifier(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_arm identifier(::interfaces::msg::DroneCommand::_identifier_type arg)
  {
    msg_.identifier = std::move(arg);
    return Init_DroneCommand_cmd_arm(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_eland
{
public:
  explicit Init_DroneCommand_cmd_eland(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_identifier cmd_eland(::interfaces::msg::DroneCommand::_cmd_eland_type arg)
  {
    msg_.cmd_eland = std::move(arg);
    return Init_DroneCommand_identifier(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_cmd_estop
{
public:
  explicit Init_DroneCommand_cmd_estop(::interfaces::msg::DroneCommand & msg)
  : msg_(msg)
  {}
  Init_DroneCommand_cmd_eland cmd_estop(::interfaces::msg::DroneCommand::_cmd_estop_type arg)
  {
    msg_.cmd_estop = std::move(arg);
    return Init_DroneCommand_cmd_eland(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

class Init_DroneCommand_timestamp
{
public:
  Init_DroneCommand_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DroneCommand_cmd_estop timestamp(::interfaces::msg::DroneCommand::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_DroneCommand_cmd_estop(msg_);
  }

private:
  ::interfaces::msg::DroneCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::DroneCommand>()
{
  return interfaces::msg::builder::Init_DroneCommand_timestamp();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__DRONE_COMMAND__BUILDER_HPP_
