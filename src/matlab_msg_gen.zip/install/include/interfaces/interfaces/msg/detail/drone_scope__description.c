// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from interfaces:msg/DroneScope.idl
// generated code does not contain a copyright notice

#include "interfaces/msg/detail/drone_scope__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_interfaces
const rosidl_type_hash_t *
interfaces__msg__DroneScope__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x91, 0x60, 0x8a, 0x82, 0x98, 0x73, 0xed, 0x5b,
      0x95, 0xb7, 0xf3, 0xea, 0x0a, 0x87, 0xbc, 0xa7,
      0xaf, 0x81, 0x54, 0xd9, 0x55, 0x7d, 0x12, 0x2f,
      0xd2, 0xd7, 0x82, 0xe2, 0x8f, 0xe2, 0x6f, 0xb6,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char interfaces__msg__DroneScope__TYPE_NAME[] = "interfaces/msg/DroneScope";

// Define type names, field names, and default values
static char interfaces__msg__DroneScope__FIELD_NAME__timestamp[] = "timestamp";
static char interfaces__msg__DroneScope__FIELD_NAME__control_output_z[] = "control_output_z";
static char interfaces__msg__DroneScope__FIELD_NAME__target_z[] = "target_z";

static rosidl_runtime_c__type_description__Field interfaces__msg__DroneScope__FIELDS[] = {
  {
    {interfaces__msg__DroneScope__FIELD_NAME__timestamp, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneScope__FIELD_NAME__control_output_z, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneScope__FIELD_NAME__target_z, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
interfaces__msg__DroneScope__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {interfaces__msg__DroneScope__TYPE_NAME, 25, 25},
      {interfaces__msg__DroneScope__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# commands which both modes can use\n"
  "float64 timestamp\n"
  "float64 control_output_z\n"
  "float64 target_z";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
interfaces__msg__DroneScope__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {interfaces__msg__DroneScope__TYPE_NAME, 25, 25},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 95, 95},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
interfaces__msg__DroneScope__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *interfaces__msg__DroneScope__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
