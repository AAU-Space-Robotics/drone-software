// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from interfaces:msg/ProbeLocations.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "interfaces/msg/detail/probe_locations__rosidl_typesupport_introspection_c.h"
#include "interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "interfaces/msg/detail/probe_locations__functions.h"
#include "interfaces/msg/detail/probe_locations__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `classification_confidence`
// Member `probes`
// Member `centroid_x`
// Member `centroid_y`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  interfaces__msg__ProbeLocations__init(message_memory);
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_fini_function(void * message_memory)
{
  interfaces__msg__ProbeLocations__fini(message_memory);
}

size_t interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__classification_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__classification_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__classification_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__classification_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__classification_confidence(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__classification_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__classification_confidence(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__classification_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__probes(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__probes(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__probes(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__probes(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__probes(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__probes(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__probes(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__probes(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__centroid_x(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__centroid_x(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__centroid_x(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__centroid_x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__centroid_x(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__centroid_x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__centroid_x(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__centroid_x(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__centroid_y(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__centroid_y(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__centroid_y(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__centroid_y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__centroid_y(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__centroid_y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__centroid_y(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__centroid_y(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_member_array[6] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__ProbeLocations, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "num_probes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__ProbeLocations, num_probes),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "classification_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__ProbeLocations, classification_confidence),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__classification_confidence,  // size() function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__classification_confidence,  // get_const(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__classification_confidence,  // get(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__classification_confidence,  // fetch(index, &value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__classification_confidence,  // assign(index, value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__classification_confidence  // resize(index) function pointer
  },
  {
    "probes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__ProbeLocations, probes),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__probes,  // size() function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__probes,  // get_const(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__probes,  // get(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__probes,  // fetch(index, &value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__probes,  // assign(index, value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__probes  // resize(index) function pointer
  },
  {
    "centroid_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__ProbeLocations, centroid_x),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__centroid_x,  // size() function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__centroid_x,  // get_const(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__centroid_x,  // get(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__centroid_x,  // fetch(index, &value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__centroid_x,  // assign(index, value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__centroid_x  // resize(index) function pointer
  },
  {
    "centroid_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__ProbeLocations, centroid_y),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__size_function__ProbeLocations__centroid_y,  // size() function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_const_function__ProbeLocations__centroid_y,  // get_const(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__get_function__ProbeLocations__centroid_y,  // get(index) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__fetch_function__ProbeLocations__centroid_y,  // fetch(index, &value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__assign_function__ProbeLocations__centroid_y,  // assign(index, value) function pointer
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__resize_function__ProbeLocations__centroid_y  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_members = {
  "interfaces__msg",  // message namespace
  "ProbeLocations",  // message name
  6,  // number of fields
  sizeof(interfaces__msg__ProbeLocations),
  false,  // has_any_key_member_
  interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_member_array,  // message members
  interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_init_function,  // function to initialize message memory (memory has to be allocated)
  interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_type_support_handle = {
  0,
  &interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_members,
  get_message_typesupport_handle_function,
  &interfaces__msg__ProbeLocations__get_type_hash,
  &interfaces__msg__ProbeLocations__get_type_description,
  &interfaces__msg__ProbeLocations__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, interfaces, msg, ProbeLocations)() {
  interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_type_support_handle.typesupport_identifier) {
    interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &interfaces__msg__ProbeLocations__rosidl_typesupport_introspection_c__ProbeLocations_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
