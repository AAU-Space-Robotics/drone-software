// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/DroneCommand.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_command.h"


#ifndef INTERFACES__MSG__DETAIL__DRONE_COMMAND__STRUCT_H_
#define INTERFACES__MSG__DETAIL__DRONE_COMMAND__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/DroneCommand in the package interfaces.
/**
  * commands which both modes can use
 */
typedef struct interfaces__msg__DroneCommand
{
  double timestamp;
  uint8_t cmd_estop;
  uint8_t cmd_eland;
  uint8_t identifier;
  /// manual commands
  uint8_t cmd_arm;
  int32_t cmd_mode;
  int32_t cmd_roll;
  int32_t cmd_pitch;
  int32_t cmd_yaw;
  int32_t cmd_thrust;
  /// autonomous commands
  int32_t cmd_auto_roll;
  int32_t cmd_auto_pitch;
  int32_t cmd_auto_yaw;
  int32_t cmd_auto_thrust;
  uint8_t cmd_auto_disarm;
} interfaces__msg__DroneCommand;

// Struct for a sequence of interfaces__msg__DroneCommand.
typedef struct interfaces__msg__DroneCommand__Sequence
{
  interfaces__msg__DroneCommand * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__DroneCommand__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__DRONE_COMMAND__STRUCT_H_
