// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/DroneCommand.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_command.hpp"


#ifndef INTERFACES__MSG__DETAIL__DRONE_COMMAND__STRUCT_HPP_
#define INTERFACES__MSG__DETAIL__DRONE_COMMAND__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__interfaces__msg__DroneCommand __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__DroneCommand __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DroneCommand_
{
  using Type = DroneCommand_<ContainerAllocator>;

  explicit DroneCommand_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->timestamp = 0.0;
      this->cmd_estop = 0;
      this->cmd_eland = 0;
      this->identifier = 0;
      this->cmd_arm = 0;
      this->cmd_mode = 0l;
      this->cmd_roll = 0l;
      this->cmd_pitch = 0l;
      this->cmd_yaw = 0l;
      this->cmd_thrust = 0l;
      this->cmd_auto_roll = 0l;
      this->cmd_auto_pitch = 0l;
      this->cmd_auto_yaw = 0l;
      this->cmd_auto_thrust = 0l;
      this->cmd_auto_disarm = 0;
    }
  }

  explicit DroneCommand_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->timestamp = 0.0;
      this->cmd_estop = 0;
      this->cmd_eland = 0;
      this->identifier = 0;
      this->cmd_arm = 0;
      this->cmd_mode = 0l;
      this->cmd_roll = 0l;
      this->cmd_pitch = 0l;
      this->cmd_yaw = 0l;
      this->cmd_thrust = 0l;
      this->cmd_auto_roll = 0l;
      this->cmd_auto_pitch = 0l;
      this->cmd_auto_yaw = 0l;
      this->cmd_auto_thrust = 0l;
      this->cmd_auto_disarm = 0;
    }
  }

  // field types and members
  using _timestamp_type =
    double;
  _timestamp_type timestamp;
  using _cmd_estop_type =
    uint8_t;
  _cmd_estop_type cmd_estop;
  using _cmd_eland_type =
    uint8_t;
  _cmd_eland_type cmd_eland;
  using _identifier_type =
    uint8_t;
  _identifier_type identifier;
  using _cmd_arm_type =
    uint8_t;
  _cmd_arm_type cmd_arm;
  using _cmd_mode_type =
    int32_t;
  _cmd_mode_type cmd_mode;
  using _cmd_roll_type =
    int32_t;
  _cmd_roll_type cmd_roll;
  using _cmd_pitch_type =
    int32_t;
  _cmd_pitch_type cmd_pitch;
  using _cmd_yaw_type =
    int32_t;
  _cmd_yaw_type cmd_yaw;
  using _cmd_thrust_type =
    int32_t;
  _cmd_thrust_type cmd_thrust;
  using _cmd_auto_roll_type =
    int32_t;
  _cmd_auto_roll_type cmd_auto_roll;
  using _cmd_auto_pitch_type =
    int32_t;
  _cmd_auto_pitch_type cmd_auto_pitch;
  using _cmd_auto_yaw_type =
    int32_t;
  _cmd_auto_yaw_type cmd_auto_yaw;
  using _cmd_auto_thrust_type =
    int32_t;
  _cmd_auto_thrust_type cmd_auto_thrust;
  using _cmd_auto_disarm_type =
    uint8_t;
  _cmd_auto_disarm_type cmd_auto_disarm;

  // setters for named parameter idiom
  Type & set__timestamp(
    const double & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__cmd_estop(
    const uint8_t & _arg)
  {
    this->cmd_estop = _arg;
    return *this;
  }
  Type & set__cmd_eland(
    const uint8_t & _arg)
  {
    this->cmd_eland = _arg;
    return *this;
  }
  Type & set__identifier(
    const uint8_t & _arg)
  {
    this->identifier = _arg;
    return *this;
  }
  Type & set__cmd_arm(
    const uint8_t & _arg)
  {
    this->cmd_arm = _arg;
    return *this;
  }
  Type & set__cmd_mode(
    const int32_t & _arg)
  {
    this->cmd_mode = _arg;
    return *this;
  }
  Type & set__cmd_roll(
    const int32_t & _arg)
  {
    this->cmd_roll = _arg;
    return *this;
  }
  Type & set__cmd_pitch(
    const int32_t & _arg)
  {
    this->cmd_pitch = _arg;
    return *this;
  }
  Type & set__cmd_yaw(
    const int32_t & _arg)
  {
    this->cmd_yaw = _arg;
    return *this;
  }
  Type & set__cmd_thrust(
    const int32_t & _arg)
  {
    this->cmd_thrust = _arg;
    return *this;
  }
  Type & set__cmd_auto_roll(
    const int32_t & _arg)
  {
    this->cmd_auto_roll = _arg;
    return *this;
  }
  Type & set__cmd_auto_pitch(
    const int32_t & _arg)
  {
    this->cmd_auto_pitch = _arg;
    return *this;
  }
  Type & set__cmd_auto_yaw(
    const int32_t & _arg)
  {
    this->cmd_auto_yaw = _arg;
    return *this;
  }
  Type & set__cmd_auto_thrust(
    const int32_t & _arg)
  {
    this->cmd_auto_thrust = _arg;
    return *this;
  }
  Type & set__cmd_auto_disarm(
    const uint8_t & _arg)
  {
    this->cmd_auto_disarm = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::DroneCommand_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::DroneCommand_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::DroneCommand_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::DroneCommand_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::DroneCommand_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::DroneCommand_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::DroneCommand_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::DroneCommand_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::DroneCommand_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::DroneCommand_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__DroneCommand
    std::shared_ptr<interfaces::msg::DroneCommand_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__DroneCommand
    std::shared_ptr<interfaces::msg::DroneCommand_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DroneCommand_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->cmd_estop != other.cmd_estop) {
      return false;
    }
    if (this->cmd_eland != other.cmd_eland) {
      return false;
    }
    if (this->identifier != other.identifier) {
      return false;
    }
    if (this->cmd_arm != other.cmd_arm) {
      return false;
    }
    if (this->cmd_mode != other.cmd_mode) {
      return false;
    }
    if (this->cmd_roll != other.cmd_roll) {
      return false;
    }
    if (this->cmd_pitch != other.cmd_pitch) {
      return false;
    }
    if (this->cmd_yaw != other.cmd_yaw) {
      return false;
    }
    if (this->cmd_thrust != other.cmd_thrust) {
      return false;
    }
    if (this->cmd_auto_roll != other.cmd_auto_roll) {
      return false;
    }
    if (this->cmd_auto_pitch != other.cmd_auto_pitch) {
      return false;
    }
    if (this->cmd_auto_yaw != other.cmd_auto_yaw) {
      return false;
    }
    if (this->cmd_auto_thrust != other.cmd_auto_thrust) {
      return false;
    }
    if (this->cmd_auto_disarm != other.cmd_auto_disarm) {
      return false;
    }
    return true;
  }
  bool operator!=(const DroneCommand_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DroneCommand_

// alias to use template instance with default allocator
using DroneCommand =
  interfaces::msg::DroneCommand_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__DRONE_COMMAND__STRUCT_HPP_
