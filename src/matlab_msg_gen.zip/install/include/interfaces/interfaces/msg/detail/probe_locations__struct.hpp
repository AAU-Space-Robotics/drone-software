// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/ProbeLocations.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_locations.hpp"


#ifndef INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__STRUCT_HPP_
#define INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__interfaces__msg__ProbeLocations __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__ProbeLocations __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ProbeLocations_
{
  using Type = ProbeLocations_<ContainerAllocator>;

  explicit ProbeLocations_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->num_probes = 0ul;
    }
  }

  explicit ProbeLocations_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->num_probes = 0ul;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _num_probes_type =
    uint32_t;
  _num_probes_type num_probes;
  using _classification_confidence_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _classification_confidence_type classification_confidence;
  using _probes_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _probes_type probes;
  using _centroid_x_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _centroid_x_type centroid_x;
  using _centroid_y_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _centroid_y_type centroid_y;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__num_probes(
    const uint32_t & _arg)
  {
    this->num_probes = _arg;
    return *this;
  }
  Type & set__classification_confidence(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->classification_confidence = _arg;
    return *this;
  }
  Type & set__probes(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->probes = _arg;
    return *this;
  }
  Type & set__centroid_x(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->centroid_x = _arg;
    return *this;
  }
  Type & set__centroid_y(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->centroid_y = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::ProbeLocations_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::ProbeLocations_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::ProbeLocations_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::ProbeLocations_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__ProbeLocations
    std::shared_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__ProbeLocations
    std::shared_ptr<interfaces::msg::ProbeLocations_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ProbeLocations_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->num_probes != other.num_probes) {
      return false;
    }
    if (this->classification_confidence != other.classification_confidence) {
      return false;
    }
    if (this->probes != other.probes) {
      return false;
    }
    if (this->centroid_x != other.centroid_x) {
      return false;
    }
    if (this->centroid_y != other.centroid_y) {
      return false;
    }
    return true;
  }
  bool operator!=(const ProbeLocations_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ProbeLocations_

// alias to use template instance with default allocator
using ProbeLocations =
  interfaces::msg::ProbeLocations_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__STRUCT_HPP_
