// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from interfaces:msg/DroneCommand.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_command.hpp"


#ifndef INTERFACES__MSG__DETAIL__DRONE_COMMAND__TRAITS_HPP_
#define INTERFACES__MSG__DETAIL__DRONE_COMMAND__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "interfaces/msg/detail/drone_command__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const DroneCommand & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: cmd_estop
  {
    out << "cmd_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_estop, out);
    out << ", ";
  }

  // member: cmd_eland
  {
    out << "cmd_eland: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_eland, out);
    out << ", ";
  }

  // member: identifier
  {
    out << "identifier: ";
    rosidl_generator_traits::value_to_yaml(msg.identifier, out);
    out << ", ";
  }

  // member: cmd_arm
  {
    out << "cmd_arm: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_arm, out);
    out << ", ";
  }

  // member: cmd_mode
  {
    out << "cmd_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_mode, out);
    out << ", ";
  }

  // member: cmd_roll
  {
    out << "cmd_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_roll, out);
    out << ", ";
  }

  // member: cmd_pitch
  {
    out << "cmd_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_pitch, out);
    out << ", ";
  }

  // member: cmd_yaw
  {
    out << "cmd_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_yaw, out);
    out << ", ";
  }

  // member: cmd_thrust
  {
    out << "cmd_thrust: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_thrust, out);
    out << ", ";
  }

  // member: cmd_auto_roll
  {
    out << "cmd_auto_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_roll, out);
    out << ", ";
  }

  // member: cmd_auto_pitch
  {
    out << "cmd_auto_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_pitch, out);
    out << ", ";
  }

  // member: cmd_auto_yaw
  {
    out << "cmd_auto_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_yaw, out);
    out << ", ";
  }

  // member: cmd_auto_thrust
  {
    out << "cmd_auto_thrust: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_thrust, out);
    out << ", ";
  }

  // member: cmd_auto_disarm
  {
    out << "cmd_auto_disarm: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_disarm, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DroneCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }

  // member: cmd_estop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_estop, out);
    out << "\n";
  }

  // member: cmd_eland
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_eland: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_eland, out);
    out << "\n";
  }

  // member: identifier
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "identifier: ";
    rosidl_generator_traits::value_to_yaml(msg.identifier, out);
    out << "\n";
  }

  // member: cmd_arm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_arm: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_arm, out);
    out << "\n";
  }

  // member: cmd_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_mode, out);
    out << "\n";
  }

  // member: cmd_roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_roll, out);
    out << "\n";
  }

  // member: cmd_pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_pitch, out);
    out << "\n";
  }

  // member: cmd_yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_yaw, out);
    out << "\n";
  }

  // member: cmd_thrust
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_thrust: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_thrust, out);
    out << "\n";
  }

  // member: cmd_auto_roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_auto_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_roll, out);
    out << "\n";
  }

  // member: cmd_auto_pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_auto_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_pitch, out);
    out << "\n";
  }

  // member: cmd_auto_yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_auto_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_yaw, out);
    out << "\n";
  }

  // member: cmd_auto_thrust
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_auto_thrust: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_thrust, out);
    out << "\n";
  }

  // member: cmd_auto_disarm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_auto_disarm: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_auto_disarm, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DroneCommand & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace interfaces

namespace rosidl_generator_traits
{

[[deprecated("use interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const interfaces::msg::DroneCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const interfaces::msg::DroneCommand & msg)
{
  return interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<interfaces::msg::DroneCommand>()
{
  return "interfaces::msg::DroneCommand";
}

template<>
inline const char * name<interfaces::msg::DroneCommand>()
{
  return "interfaces/msg/DroneCommand";
}

template<>
struct has_fixed_size<interfaces::msg::DroneCommand>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<interfaces::msg::DroneCommand>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<interfaces::msg::DroneCommand>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INTERFACES__MSG__DETAIL__DRONE_COMMAND__TRAITS_HPP_
