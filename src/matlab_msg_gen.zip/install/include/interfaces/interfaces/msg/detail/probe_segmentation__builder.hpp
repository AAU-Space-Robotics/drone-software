// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/ProbeSegmentation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_segmentation.hpp"


#ifndef INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/probe_segmentation__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_ProbeSegmentation_mask_height
{
public:
  explicit Init_ProbeSegmentation_mask_height(::interfaces::msg::ProbeSegmentation & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::ProbeSegmentation mask_height(::interfaces::msg::ProbeSegmentation::_mask_height_type arg)
  {
    msg_.mask_height = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

class Init_ProbeSegmentation_mask_width
{
public:
  explicit Init_ProbeSegmentation_mask_width(::interfaces::msg::ProbeSegmentation & msg)
  : msg_(msg)
  {}
  Init_ProbeSegmentation_mask_height mask_width(::interfaces::msg::ProbeSegmentation::_mask_width_type arg)
  {
    msg_.mask_width = std::move(arg);
    return Init_ProbeSegmentation_mask_height(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

class Init_ProbeSegmentation_mask
{
public:
  explicit Init_ProbeSegmentation_mask(::interfaces::msg::ProbeSegmentation & msg)
  : msg_(msg)
  {}
  Init_ProbeSegmentation_mask_width mask(::interfaces::msg::ProbeSegmentation::_mask_type arg)
  {
    msg_.mask = std::move(arg);
    return Init_ProbeSegmentation_mask_width(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

class Init_ProbeSegmentation_box
{
public:
  explicit Init_ProbeSegmentation_box(::interfaces::msg::ProbeSegmentation & msg)
  : msg_(msg)
  {}
  Init_ProbeSegmentation_mask box(::interfaces::msg::ProbeSegmentation::_box_type arg)
  {
    msg_.box = std::move(arg);
    return Init_ProbeSegmentation_mask(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

class Init_ProbeSegmentation_confidence
{
public:
  explicit Init_ProbeSegmentation_confidence(::interfaces::msg::ProbeSegmentation & msg)
  : msg_(msg)
  {}
  Init_ProbeSegmentation_box confidence(::interfaces::msg::ProbeSegmentation::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_ProbeSegmentation_box(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

class Init_ProbeSegmentation_class_name
{
public:
  explicit Init_ProbeSegmentation_class_name(::interfaces::msg::ProbeSegmentation & msg)
  : msg_(msg)
  {}
  Init_ProbeSegmentation_confidence class_name(::interfaces::msg::ProbeSegmentation::_class_name_type arg)
  {
    msg_.class_name = std::move(arg);
    return Init_ProbeSegmentation_confidence(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

class Init_ProbeSegmentation_id
{
public:
  Init_ProbeSegmentation_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProbeSegmentation_class_name id(::interfaces::msg::ProbeSegmentation::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_ProbeSegmentation_class_name(msg_);
  }

private:
  ::interfaces::msg::ProbeSegmentation msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::ProbeSegmentation>()
{
  return interfaces::msg::builder::Init_ProbeSegmentation_id();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__BUILDER_HPP_
