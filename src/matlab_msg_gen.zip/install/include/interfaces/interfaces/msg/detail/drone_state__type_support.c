// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "interfaces/msg/detail/drone_state__rosidl_typesupport_introspection_c.h"
#include "interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "interfaces/msg/detail/drone_state__functions.h"
#include "interfaces/msg/detail/drone_state__struct.h"


// Include directives for member types
// Member `position`
// Member `velocity`
// Member `orientation`
// Member `target_position`
// Member `acceleration`
// Member `actuator_speeds`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  interfaces__msg__DroneState__init(message_memory);
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_fini_function(void * message_memory)
{
  interfaces__msg__DroneState__fini(message_memory);
}

size_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__position(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__position(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__position(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__position(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__position(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__position(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__position(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__position(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__velocity(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__velocity(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__velocity(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__velocity(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__velocity(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__velocity(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__velocity(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__velocity(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__orientation(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__orientation(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__orientation(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__orientation(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__orientation(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__orientation(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__orientation(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__orientation(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__target_position(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__target_position(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__target_position(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__target_position(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__target_position(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__target_position(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__target_position(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__target_position(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__acceleration(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__acceleration(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__acceleration(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__acceleration(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__acceleration(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__acceleration(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__acceleration(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__acceleration(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__actuator_speeds(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__actuator_speeds(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__actuator_speeds(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__actuator_speeds(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__actuator_speeds(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__actuator_speeds(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__actuator_speeds(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__actuator_speeds(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_member_array[18] = {
  {
    "timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "position_timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, position_timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "position",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, position),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__position,  // size() function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__position,  // get_const(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__position,  // get(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__position,  // fetch(index, &value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__position,  // assign(index, value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__position  // resize(index) function pointer
  },
  {
    "velocity_timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, velocity_timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, velocity),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__velocity,  // size() function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__velocity,  // get_const(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__velocity,  // get(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__velocity,  // fetch(index, &value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__velocity,  // assign(index, value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__velocity  // resize(index) function pointer
  },
  {
    "orientation",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, orientation),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__orientation,  // size() function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__orientation,  // get_const(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__orientation,  // get(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__orientation,  // fetch(index, &value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__orientation,  // assign(index, value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__orientation  // resize(index) function pointer
  },
  {
    "target_position",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, target_position),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__target_position,  // size() function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__target_position,  // get_const(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__target_position,  // get(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__target_position,  // fetch(index, &value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__target_position,  // assign(index, value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__target_position  // resize(index) function pointer
  },
  {
    "acceleration",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, acceleration),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__acceleration,  // size() function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__acceleration,  // get_const(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__acceleration,  // get(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__acceleration,  // fetch(index, &value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__acceleration,  // assign(index, value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__acceleration  // resize(index) function pointer
  },
  {
    "battery_state_timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, battery_state_timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_voltage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, battery_voltage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_current",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, battery_current),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_percentage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, battery_percentage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_discharged_mah",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, battery_discharged_mah),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_average_current",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, battery_average_current),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "actuator_speeds",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, actuator_speeds),  // bytes offset in struct
    NULL,  // default value
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__size_function__DroneState__actuator_speeds,  // size() function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_const_function__DroneState__actuator_speeds,  // get_const(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__get_function__DroneState__actuator_speeds,  // get(index) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__fetch_function__DroneState__actuator_speeds,  // fetch(index, &value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__assign_function__DroneState__actuator_speeds,  // assign(index, value) function pointer
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__resize_function__DroneState__actuator_speeds  // resize(index) function pointer
  },
  {
    "arming_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, arming_state),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "estop",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, estop),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "flight_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces__msg__DroneState, flight_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_members = {
  "interfaces__msg",  // message namespace
  "DroneState",  // message name
  18,  // number of fields
  sizeof(interfaces__msg__DroneState),
  false,  // has_any_key_member_
  interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_member_array,  // message members
  interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_init_function,  // function to initialize message memory (memory has to be allocated)
  interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_type_support_handle = {
  0,
  &interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_members,
  get_message_typesupport_handle_function,
  &interfaces__msg__DroneState__get_type_hash,
  &interfaces__msg__DroneState__get_type_description,
  &interfaces__msg__DroneState__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, interfaces, msg, DroneState)() {
  if (!interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_type_support_handle.typesupport_identifier) {
    interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &interfaces__msg__DroneState__rosidl_typesupport_introspection_c__DroneState_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
