// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from interfaces:msg/DroneCommand.idl
// generated code does not contain a copyright notice

#include "interfaces/msg/detail/drone_command__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_interfaces
const rosidl_type_hash_t *
interfaces__msg__DroneCommand__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x5e, 0x0c, 0x85, 0x85, 0xb6, 0x03, 0x6f, 0xed,
      0x86, 0x5e, 0x41, 0xdc, 0xaf, 0x2b, 0xd3, 0xa6,
      0x72, 0xa9, 0x54, 0xb3, 0x4d, 0x3c, 0x98, 0x9a,
      0x04, 0xfe, 0x89, 0xf3, 0xc6, 0x53, 0x58, 0xa9,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char interfaces__msg__DroneCommand__TYPE_NAME[] = "interfaces/msg/DroneCommand";

// Define type names, field names, and default values
static char interfaces__msg__DroneCommand__FIELD_NAME__timestamp[] = "timestamp";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_estop[] = "cmd_estop";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_eland[] = "cmd_eland";
static char interfaces__msg__DroneCommand__FIELD_NAME__identifier[] = "identifier";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_arm[] = "cmd_arm";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_mode[] = "cmd_mode";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_roll[] = "cmd_roll";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_pitch[] = "cmd_pitch";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_yaw[] = "cmd_yaw";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_thrust[] = "cmd_thrust";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_roll[] = "cmd_auto_roll";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_pitch[] = "cmd_auto_pitch";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_yaw[] = "cmd_auto_yaw";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_thrust[] = "cmd_auto_thrust";
static char interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_disarm[] = "cmd_auto_disarm";

static rosidl_runtime_c__type_description__Field interfaces__msg__DroneCommand__FIELDS[] = {
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__timestamp, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_estop, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_eland, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__identifier, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_arm, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_mode, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_roll, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_pitch, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_yaw, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_thrust, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_roll, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_pitch, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_yaw, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_thrust, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneCommand__FIELD_NAME__cmd_auto_disarm, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
interfaces__msg__DroneCommand__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {interfaces__msg__DroneCommand__TYPE_NAME, 27, 27},
      {interfaces__msg__DroneCommand__FIELDS, 15, 15},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# commands which both modes can use\n"
  "float64 timestamp\n"
  "uint8 cmd_estop\n"
  "uint8 cmd_eland\n"
  "uint8 identifier\n"
  "\n"
  "# manual commands\n"
  "uint8 cmd_arm\n"
  "int32 cmd_mode \n"
  "\n"
  "int32 cmd_roll\n"
  "int32 cmd_pitch\n"
  "int32 cmd_yaw\n"
  "int32 cmd_thrust\n"
  "\n"
  "# autonomous commands\n"
  "int32 cmd_auto_roll\n"
  "int32 cmd_auto_pitch\n"
  "int32 cmd_auto_yaw\n"
  "int32 cmd_auto_thrust\n"
  "uint8 cmd_auto_disarm\n"
  "\n"
  "\n"
  "\n"
  "#DroneCmd\n"
  "#float64 timestamp\n"
  "#int8 id\n"
  "#int8 mode\n"
  "#uint8 emergencystop\n"
  "#float64[2] cmd_jointangles\n"
  "#float64[2] cmd_jointspeeds\n"
  "#float64[2] cmd_torques\n"
  "";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
interfaces__msg__DroneCommand__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {interfaces__msg__DroneCommand__TYPE_NAME, 27, 27},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 496, 496},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
interfaces__msg__DroneCommand__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *interfaces__msg__DroneCommand__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
