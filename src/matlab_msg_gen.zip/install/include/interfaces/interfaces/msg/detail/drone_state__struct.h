// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_state.h"


#ifndef INTERFACES__MSG__DETAIL__DRONE_STATE__STRUCT_H_
#define INTERFACES__MSG__DETAIL__DRONE_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'position'
// Member 'velocity'
// Member 'orientation'
// Member 'target_position'
// Member 'acceleration'
// Member 'actuator_speeds'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/DroneState in the package interfaces.
typedef struct interfaces__msg__DroneState
{
  double timestamp;
  /// int8 id
  /// int8 mode
  double position_timestamp;
  /// x, y, z
  rosidl_runtime_c__float__Sequence position;
  double velocity_timestamp;
  /// x, y, z
  rosidl_runtime_c__float__Sequence velocity;
  /// roll, pitch, yaw
  rosidl_runtime_c__float__Sequence orientation;
  /// x, y, z
  rosidl_runtime_c__float__Sequence target_position;
  rosidl_runtime_c__float__Sequence acceleration;
  double battery_state_timestamp;
  /// in volts
  float battery_voltage;
  float battery_current;
  /// 0.0 to 100.0
  float battery_percentage;
  float battery_discharged_mah;
  float battery_average_current;
  /// Speed of the four actuators from 0 to 1
  rosidl_runtime_c__float__Sequence actuator_speeds;
  uint8_t arming_state;
  uint8_t trajectory_mode;
  uint8_t estop;
  int16_t flight_mode;
  double flight_time;
} interfaces__msg__DroneState;

// Struct for a sequence of interfaces__msg__DroneState.
typedef struct interfaces__msg__DroneState__Sequence
{
  interfaces__msg__DroneState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__DroneState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__DRONE_STATE__STRUCT_H_
