// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/ProbeSegmentation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_segmentation.h"


#ifndef INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__STRUCT_H_
#define INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'class_name'
#include "rosidl_runtime_c/string.h"
// Member 'box'
// Member 'mask'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/ProbeSegmentation in the package interfaces.
/**
  * ProbeSegmentation.msg
 */
typedef struct interfaces__msg__ProbeSegmentation
{
  /// Detection ID
  uint32_t id;
  /// Class name of detected object
  rosidl_runtime_c__String class_name;
  /// Confidence score
  float confidence;
  /// Bounding box [x_min, y_min, x_max, y_max]
  rosidl_runtime_c__float__Sequence box;
  /// Flattened segmentation mask points
  rosidl_runtime_c__float__Sequence mask;
  /// Width of original mask
  uint32_t mask_width;
  /// Height of original mask
  uint32_t mask_height;
} interfaces__msg__ProbeSegmentation;

// Struct for a sequence of interfaces__msg__ProbeSegmentation.
typedef struct interfaces__msg__ProbeSegmentation__Sequence
{
  interfaces__msg__ProbeSegmentation * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__ProbeSegmentation__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__STRUCT_H_
