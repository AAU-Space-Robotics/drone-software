// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/ProbeLocations.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_locations.hpp"


#ifndef INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/probe_locations__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_ProbeLocations_centroid_y
{
public:
  explicit Init_ProbeLocations_centroid_y(::interfaces::msg::ProbeLocations & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::ProbeLocations centroid_y(::interfaces::msg::ProbeLocations::_centroid_y_type arg)
  {
    msg_.centroid_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::ProbeLocations msg_;
};

class Init_ProbeLocations_centroid_x
{
public:
  explicit Init_ProbeLocations_centroid_x(::interfaces::msg::ProbeLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeLocations_centroid_y centroid_x(::interfaces::msg::ProbeLocations::_centroid_x_type arg)
  {
    msg_.centroid_x = std::move(arg);
    return Init_ProbeLocations_centroid_y(msg_);
  }

private:
  ::interfaces::msg::ProbeLocations msg_;
};

class Init_ProbeLocations_probes
{
public:
  explicit Init_ProbeLocations_probes(::interfaces::msg::ProbeLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeLocations_centroid_x probes(::interfaces::msg::ProbeLocations::_probes_type arg)
  {
    msg_.probes = std::move(arg);
    return Init_ProbeLocations_centroid_x(msg_);
  }

private:
  ::interfaces::msg::ProbeLocations msg_;
};

class Init_ProbeLocations_classification_confidence
{
public:
  explicit Init_ProbeLocations_classification_confidence(::interfaces::msg::ProbeLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeLocations_probes classification_confidence(::interfaces::msg::ProbeLocations::_classification_confidence_type arg)
  {
    msg_.classification_confidence = std::move(arg);
    return Init_ProbeLocations_probes(msg_);
  }

private:
  ::interfaces::msg::ProbeLocations msg_;
};

class Init_ProbeLocations_num_probes
{
public:
  explicit Init_ProbeLocations_num_probes(::interfaces::msg::ProbeLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeLocations_classification_confidence num_probes(::interfaces::msg::ProbeLocations::_num_probes_type arg)
  {
    msg_.num_probes = std::move(arg);
    return Init_ProbeLocations_classification_confidence(msg_);
  }

private:
  ::interfaces::msg::ProbeLocations msg_;
};

class Init_ProbeLocations_header
{
public:
  Init_ProbeLocations_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProbeLocations_num_probes header(::interfaces::msg::ProbeLocations::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ProbeLocations_num_probes(msg_);
  }

private:
  ::interfaces::msg::ProbeLocations msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::ProbeLocations>()
{
  return interfaces::msg::builder::Init_ProbeLocations_header();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__BUILDER_HPP_
