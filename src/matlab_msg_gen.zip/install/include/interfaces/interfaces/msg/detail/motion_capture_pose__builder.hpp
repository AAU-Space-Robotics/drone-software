// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/MotionCapturePose.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/motion_capture_pose.hpp"


#ifndef INTERFACES__MSG__DETAIL__MOTION_CAPTURE_POSE__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__MOTION_CAPTURE_POSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/motion_capture_pose__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_MotionCapturePose_yaw
{
public:
  explicit Init_MotionCapturePose_yaw(::interfaces::msg::MotionCapturePose & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::MotionCapturePose yaw(::interfaces::msg::MotionCapturePose::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

class Init_MotionCapturePose_pitch
{
public:
  explicit Init_MotionCapturePose_pitch(::interfaces::msg::MotionCapturePose & msg)
  : msg_(msg)
  {}
  Init_MotionCapturePose_yaw pitch(::interfaces::msg::MotionCapturePose::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_MotionCapturePose_yaw(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

class Init_MotionCapturePose_roll
{
public:
  explicit Init_MotionCapturePose_roll(::interfaces::msg::MotionCapturePose & msg)
  : msg_(msg)
  {}
  Init_MotionCapturePose_pitch roll(::interfaces::msg::MotionCapturePose::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_MotionCapturePose_pitch(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

class Init_MotionCapturePose_z
{
public:
  explicit Init_MotionCapturePose_z(::interfaces::msg::MotionCapturePose & msg)
  : msg_(msg)
  {}
  Init_MotionCapturePose_roll z(::interfaces::msg::MotionCapturePose::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_MotionCapturePose_roll(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

class Init_MotionCapturePose_y
{
public:
  explicit Init_MotionCapturePose_y(::interfaces::msg::MotionCapturePose & msg)
  : msg_(msg)
  {}
  Init_MotionCapturePose_z y(::interfaces::msg::MotionCapturePose::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_MotionCapturePose_z(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

class Init_MotionCapturePose_x
{
public:
  explicit Init_MotionCapturePose_x(::interfaces::msg::MotionCapturePose & msg)
  : msg_(msg)
  {}
  Init_MotionCapturePose_y x(::interfaces::msg::MotionCapturePose::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_MotionCapturePose_y(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

class Init_MotionCapturePose_timestamp
{
public:
  Init_MotionCapturePose_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCapturePose_x timestamp(::interfaces::msg::MotionCapturePose::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_MotionCapturePose_x(msg_);
  }

private:
  ::interfaces::msg::MotionCapturePose msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::MotionCapturePose>()
{
  return interfaces::msg::builder::Init_MotionCapturePose_timestamp();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__MOTION_CAPTURE_POSE__BUILDER_HPP_
