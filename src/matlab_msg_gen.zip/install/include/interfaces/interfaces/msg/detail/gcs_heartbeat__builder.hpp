// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/GcsHeartbeat.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/gcs_heartbeat.hpp"


#ifndef INTERFACES__MSG__DETAIL__GCS_HEARTBEAT__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__GCS_HEARTBEAT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/gcs_heartbeat__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_GcsHeartbeat_gcs_nominal
{
public:
  explicit Init_GcsHeartbeat_gcs_nominal(::interfaces::msg::GcsHeartbeat & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::GcsHeartbeat gcs_nominal(::interfaces::msg::GcsHeartbeat::_gcs_nominal_type arg)
  {
    msg_.gcs_nominal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::GcsHeartbeat msg_;
};

class Init_GcsHeartbeat_timestamp
{
public:
  Init_GcsHeartbeat_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GcsHeartbeat_gcs_nominal timestamp(::interfaces::msg::GcsHeartbeat::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_GcsHeartbeat_gcs_nominal(msg_);
  }

private:
  ::interfaces::msg::GcsHeartbeat msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::GcsHeartbeat>()
{
  return interfaces::msg::builder::Init_GcsHeartbeat_timestamp();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__GCS_HEARTBEAT__BUILDER_HPP_
