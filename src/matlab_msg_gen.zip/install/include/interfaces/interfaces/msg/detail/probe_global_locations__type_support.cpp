// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from interfaces:msg/ProbeGlobalLocations.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "interfaces/msg/detail/probe_global_locations__functions.h"
#include "interfaces/msg/detail/probe_global_locations__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ProbeGlobalLocations_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) interfaces::msg::ProbeGlobalLocations(_init);
}

void ProbeGlobalLocations_fini_function(void * message_memory)
{
  auto typed_message = static_cast<interfaces::msg::ProbeGlobalLocations *>(message_memory);
  typed_message->~ProbeGlobalLocations();
}

size_t size_function__ProbeGlobalLocations__x(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<float> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ProbeGlobalLocations__x(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<float> *>(untyped_member);
  return &member[index];
}

void * get_function__ProbeGlobalLocations__x(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<float> *>(untyped_member);
  return &member[index];
}

void fetch_function__ProbeGlobalLocations__x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__ProbeGlobalLocations__x(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__ProbeGlobalLocations__x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__ProbeGlobalLocations__x(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

void resize_function__ProbeGlobalLocations__x(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<float> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ProbeGlobalLocations__y(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<float> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ProbeGlobalLocations__y(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<float> *>(untyped_member);
  return &member[index];
}

void * get_function__ProbeGlobalLocations__y(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<float> *>(untyped_member);
  return &member[index];
}

void fetch_function__ProbeGlobalLocations__y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__ProbeGlobalLocations__y(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__ProbeGlobalLocations__y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__ProbeGlobalLocations__y(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

void resize_function__ProbeGlobalLocations__y(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<float> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ProbeGlobalLocations__z(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<float> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ProbeGlobalLocations__z(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<float> *>(untyped_member);
  return &member[index];
}

void * get_function__ProbeGlobalLocations__z(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<float> *>(untyped_member);
  return &member[index];
}

void fetch_function__ProbeGlobalLocations__z(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__ProbeGlobalLocations__z(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__ProbeGlobalLocations__z(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__ProbeGlobalLocations__z(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

void resize_function__ProbeGlobalLocations__z(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<float> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ProbeGlobalLocations__confidence(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<float> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ProbeGlobalLocations__confidence(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<float> *>(untyped_member);
  return &member[index];
}

void * get_function__ProbeGlobalLocations__confidence(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<float> *>(untyped_member);
  return &member[index];
}

void fetch_function__ProbeGlobalLocations__confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__ProbeGlobalLocations__confidence(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__ProbeGlobalLocations__confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__ProbeGlobalLocations__confidence(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

void resize_function__ProbeGlobalLocations__confidence(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<float> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ProbeGlobalLocations__contribution(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<int32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ProbeGlobalLocations__contribution(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<int32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__ProbeGlobalLocations__contribution(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<int32_t> *>(untyped_member);
  return &member[index];
}

void fetch_function__ProbeGlobalLocations__contribution(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const int32_t *>(
    get_const_function__ProbeGlobalLocations__contribution(untyped_member, index));
  auto & value = *reinterpret_cast<int32_t *>(untyped_value);
  value = item;
}

void assign_function__ProbeGlobalLocations__contribution(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<int32_t *>(
    get_function__ProbeGlobalLocations__contribution(untyped_member, index));
  const auto & value = *reinterpret_cast<const int32_t *>(untyped_value);
  item = value;
}

void resize_function__ProbeGlobalLocations__contribution(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<int32_t> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ProbeGlobalLocations_message_member_array[7] = {
  {
    "x",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, x),  // bytes offset in struct
    nullptr,  // default value
    size_function__ProbeGlobalLocations__x,  // size() function pointer
    get_const_function__ProbeGlobalLocations__x,  // get_const(index) function pointer
    get_function__ProbeGlobalLocations__x,  // get(index) function pointer
    fetch_function__ProbeGlobalLocations__x,  // fetch(index, &value) function pointer
    assign_function__ProbeGlobalLocations__x,  // assign(index, value) function pointer
    resize_function__ProbeGlobalLocations__x  // resize(index) function pointer
  },
  {
    "y",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, y),  // bytes offset in struct
    nullptr,  // default value
    size_function__ProbeGlobalLocations__y,  // size() function pointer
    get_const_function__ProbeGlobalLocations__y,  // get_const(index) function pointer
    get_function__ProbeGlobalLocations__y,  // get(index) function pointer
    fetch_function__ProbeGlobalLocations__y,  // fetch(index, &value) function pointer
    assign_function__ProbeGlobalLocations__y,  // assign(index, value) function pointer
    resize_function__ProbeGlobalLocations__y  // resize(index) function pointer
  },
  {
    "z",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, z),  // bytes offset in struct
    nullptr,  // default value
    size_function__ProbeGlobalLocations__z,  // size() function pointer
    get_const_function__ProbeGlobalLocations__z,  // get_const(index) function pointer
    get_function__ProbeGlobalLocations__z,  // get(index) function pointer
    fetch_function__ProbeGlobalLocations__z,  // fetch(index, &value) function pointer
    assign_function__ProbeGlobalLocations__z,  // assign(index, value) function pointer
    resize_function__ProbeGlobalLocations__z  // resize(index) function pointer
  },
  {
    "confidence",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, confidence),  // bytes offset in struct
    nullptr,  // default value
    size_function__ProbeGlobalLocations__confidence,  // size() function pointer
    get_const_function__ProbeGlobalLocations__confidence,  // get_const(index) function pointer
    get_function__ProbeGlobalLocations__confidence,  // get(index) function pointer
    fetch_function__ProbeGlobalLocations__confidence,  // fetch(index, &value) function pointer
    assign_function__ProbeGlobalLocations__confidence,  // assign(index, value) function pointer
    resize_function__ProbeGlobalLocations__confidence  // resize(index) function pointer
  },
  {
    "contribution",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, contribution),  // bytes offset in struct
    nullptr,  // default value
    size_function__ProbeGlobalLocations__contribution,  // size() function pointer
    get_const_function__ProbeGlobalLocations__contribution,  // get_const(index) function pointer
    get_function__ProbeGlobalLocations__contribution,  // get(index) function pointer
    fetch_function__ProbeGlobalLocations__contribution,  // fetch(index, &value) function pointer
    assign_function__ProbeGlobalLocations__contribution,  // assign(index, value) function pointer
    resize_function__ProbeGlobalLocations__contribution  // resize(index) function pointer
  },
  {
    "probe_count",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, probe_count),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "stamp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<builtin_interfaces::msg::Time>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(interfaces::msg::ProbeGlobalLocations, stamp),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ProbeGlobalLocations_message_members = {
  "interfaces::msg",  // message namespace
  "ProbeGlobalLocations",  // message name
  7,  // number of fields
  sizeof(interfaces::msg::ProbeGlobalLocations),
  false,  // has_any_key_member_
  ProbeGlobalLocations_message_member_array,  // message members
  ProbeGlobalLocations_init_function,  // function to initialize message memory (memory has to be allocated)
  ProbeGlobalLocations_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ProbeGlobalLocations_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ProbeGlobalLocations_message_members,
  get_message_typesupport_handle_function,
  &interfaces__msg__ProbeGlobalLocations__get_type_hash,
  &interfaces__msg__ProbeGlobalLocations__get_type_description,
  &interfaces__msg__ProbeGlobalLocations__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<interfaces::msg::ProbeGlobalLocations>()
{
  return &::interfaces::msg::rosidl_typesupport_introspection_cpp::ProbeGlobalLocations_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, interfaces, msg, ProbeGlobalLocations)() {
  return &::interfaces::msg::rosidl_typesupport_introspection_cpp::ProbeGlobalLocations_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
