// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_state.hpp"


#ifndef INTERFACES__MSG__DETAIL__DRONE_STATE__TRAITS_HPP_
#define INTERFACES__MSG__DETAIL__DRONE_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "interfaces/msg/detail/drone_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const DroneState & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: position_timestamp
  {
    out << "position_timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.position_timestamp, out);
    out << ", ";
  }

  // member: position
  {
    if (msg.position.size() == 0) {
      out << "position: []";
    } else {
      out << "position: [";
      size_t pending_items = msg.position.size();
      for (auto item : msg.position) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: velocity_timestamp
  {
    out << "velocity_timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.velocity_timestamp, out);
    out << ", ";
  }

  // member: velocity
  {
    if (msg.velocity.size() == 0) {
      out << "velocity: []";
    } else {
      out << "velocity: [";
      size_t pending_items = msg.velocity.size();
      for (auto item : msg.velocity) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: orientation
  {
    if (msg.orientation.size() == 0) {
      out << "orientation: []";
    } else {
      out << "orientation: [";
      size_t pending_items = msg.orientation.size();
      for (auto item : msg.orientation) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: target_position
  {
    if (msg.target_position.size() == 0) {
      out << "target_position: []";
    } else {
      out << "target_position: [";
      size_t pending_items = msg.target_position.size();
      for (auto item : msg.target_position) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: acceleration
  {
    if (msg.acceleration.size() == 0) {
      out << "acceleration: []";
    } else {
      out << "acceleration: [";
      size_t pending_items = msg.acceleration.size();
      for (auto item : msg.acceleration) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: battery_state_timestamp
  {
    out << "battery_state_timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_state_timestamp, out);
    out << ", ";
  }

  // member: battery_voltage
  {
    out << "battery_voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage, out);
    out << ", ";
  }

  // member: battery_current
  {
    out << "battery_current: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_current, out);
    out << ", ";
  }

  // member: battery_percentage
  {
    out << "battery_percentage: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_percentage, out);
    out << ", ";
  }

  // member: battery_discharged_mah
  {
    out << "battery_discharged_mah: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_discharged_mah, out);
    out << ", ";
  }

  // member: battery_average_current
  {
    out << "battery_average_current: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_average_current, out);
    out << ", ";
  }

  // member: actuator_speeds
  {
    if (msg.actuator_speeds.size() == 0) {
      out << "actuator_speeds: []";
    } else {
      out << "actuator_speeds: [";
      size_t pending_items = msg.actuator_speeds.size();
      for (auto item : msg.actuator_speeds) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: arming_state
  {
    out << "arming_state: ";
    rosidl_generator_traits::value_to_yaml(msg.arming_state, out);
    out << ", ";
  }

  // member: trajectory_mode
  {
    out << "trajectory_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.trajectory_mode, out);
    out << ", ";
  }

  // member: estop
  {
    out << "estop: ";
    rosidl_generator_traits::value_to_yaml(msg.estop, out);
    out << ", ";
  }

  // member: flight_mode
  {
    out << "flight_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.flight_mode, out);
    out << ", ";
  }

  // member: flight_time
  {
    out << "flight_time: ";
    rosidl_generator_traits::value_to_yaml(msg.flight_time, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DroneState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }

  // member: position_timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.position_timestamp, out);
    out << "\n";
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.position.size() == 0) {
      out << "position: []\n";
    } else {
      out << "position:\n";
      for (auto item : msg.position) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: velocity_timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "velocity_timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.velocity_timestamp, out);
    out << "\n";
  }

  // member: velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.velocity.size() == 0) {
      out << "velocity: []\n";
    } else {
      out << "velocity:\n";
      for (auto item : msg.velocity) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: orientation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.orientation.size() == 0) {
      out << "orientation: []\n";
    } else {
      out << "orientation:\n";
      for (auto item : msg.orientation) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: target_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.target_position.size() == 0) {
      out << "target_position: []\n";
    } else {
      out << "target_position:\n";
      for (auto item : msg.target_position) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: acceleration
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.acceleration.size() == 0) {
      out << "acceleration: []\n";
    } else {
      out << "acceleration:\n";
      for (auto item : msg.acceleration) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: battery_state_timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_state_timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_state_timestamp, out);
    out << "\n";
  }

  // member: battery_voltage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage, out);
    out << "\n";
  }

  // member: battery_current
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_current: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_current, out);
    out << "\n";
  }

  // member: battery_percentage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_percentage: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_percentage, out);
    out << "\n";
  }

  // member: battery_discharged_mah
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_discharged_mah: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_discharged_mah, out);
    out << "\n";
  }

  // member: battery_average_current
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_average_current: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_average_current, out);
    out << "\n";
  }

  // member: actuator_speeds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.actuator_speeds.size() == 0) {
      out << "actuator_speeds: []\n";
    } else {
      out << "actuator_speeds:\n";
      for (auto item : msg.actuator_speeds) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: arming_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "arming_state: ";
    rosidl_generator_traits::value_to_yaml(msg.arming_state, out);
    out << "\n";
  }

  // member: trajectory_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "trajectory_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.trajectory_mode, out);
    out << "\n";
  }

  // member: estop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "estop: ";
    rosidl_generator_traits::value_to_yaml(msg.estop, out);
    out << "\n";
  }

  // member: flight_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "flight_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.flight_mode, out);
    out << "\n";
  }

  // member: flight_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "flight_time: ";
    rosidl_generator_traits::value_to_yaml(msg.flight_time, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DroneState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace interfaces

namespace rosidl_generator_traits
{

[[deprecated("use interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const interfaces::msg::DroneState & msg,
  std::ostream & out, size_t indentation = 0)
{
  interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const interfaces::msg::DroneState & msg)
{
  return interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<interfaces::msg::DroneState>()
{
  return "interfaces::msg::DroneState";
}

template<>
inline const char * name<interfaces::msg::DroneState>()
{
  return "interfaces/msg/DroneState";
}

template<>
struct has_fixed_size<interfaces::msg::DroneState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<interfaces::msg::DroneState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<interfaces::msg::DroneState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INTERFACES__MSG__DETAIL__DRONE_STATE__TRAITS_HPP_
