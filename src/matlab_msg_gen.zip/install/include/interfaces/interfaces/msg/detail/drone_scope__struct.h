// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/DroneScope.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_scope.h"


#ifndef INTERFACES__MSG__DETAIL__DRONE_SCOPE__STRUCT_H_
#define INTERFACES__MSG__DETAIL__DRONE_SCOPE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/DroneScope in the package interfaces.
/**
  * commands which both modes can use
 */
typedef struct interfaces__msg__DroneScope
{
  double timestamp;
  double control_output_z;
  double target_z;
} interfaces__msg__DroneScope;

// Struct for a sequence of interfaces__msg__DroneScope.
typedef struct interfaces__msg__DroneScope__Sequence
{
  interfaces__msg__DroneScope * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__DroneScope__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__DRONE_SCOPE__STRUCT_H_
