// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice
#include "interfaces/msg/detail/drone_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `position`
// Member `velocity`
// Member `orientation`
// Member `target_position`
// Member `acceleration`
// Member `actuator_speeds`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
interfaces__msg__DroneState__init(interfaces__msg__DroneState * msg)
{
  if (!msg) {
    return false;
  }
  // timestamp
  // position_timestamp
  // position
  if (!rosidl_runtime_c__float__Sequence__init(&msg->position, 0)) {
    interfaces__msg__DroneState__fini(msg);
    return false;
  }
  // velocity_timestamp
  // velocity
  if (!rosidl_runtime_c__float__Sequence__init(&msg->velocity, 0)) {
    interfaces__msg__DroneState__fini(msg);
    return false;
  }
  // orientation
  if (!rosidl_runtime_c__float__Sequence__init(&msg->orientation, 0)) {
    interfaces__msg__DroneState__fini(msg);
    return false;
  }
  // target_position
  if (!rosidl_runtime_c__float__Sequence__init(&msg->target_position, 0)) {
    interfaces__msg__DroneState__fini(msg);
    return false;
  }
  // acceleration
  if (!rosidl_runtime_c__float__Sequence__init(&msg->acceleration, 0)) {
    interfaces__msg__DroneState__fini(msg);
    return false;
  }
  // battery_state_timestamp
  // battery_voltage
  // battery_current
  // battery_percentage
  // battery_discharged_mah
  // battery_average_current
  // actuator_speeds
  if (!rosidl_runtime_c__float__Sequence__init(&msg->actuator_speeds, 0)) {
    interfaces__msg__DroneState__fini(msg);
    return false;
  }
  // arming_state
  // trajectory_mode
  // estop
  // flight_mode
  // flight_time
  return true;
}

void
interfaces__msg__DroneState__fini(interfaces__msg__DroneState * msg)
{
  if (!msg) {
    return;
  }
  // timestamp
  // position_timestamp
  // position
  rosidl_runtime_c__float__Sequence__fini(&msg->position);
  // velocity_timestamp
  // velocity
  rosidl_runtime_c__float__Sequence__fini(&msg->velocity);
  // orientation
  rosidl_runtime_c__float__Sequence__fini(&msg->orientation);
  // target_position
  rosidl_runtime_c__float__Sequence__fini(&msg->target_position);
  // acceleration
  rosidl_runtime_c__float__Sequence__fini(&msg->acceleration);
  // battery_state_timestamp
  // battery_voltage
  // battery_current
  // battery_percentage
  // battery_discharged_mah
  // battery_average_current
  // actuator_speeds
  rosidl_runtime_c__float__Sequence__fini(&msg->actuator_speeds);
  // arming_state
  // trajectory_mode
  // estop
  // flight_mode
  // flight_time
}

bool
interfaces__msg__DroneState__are_equal(const interfaces__msg__DroneState * lhs, const interfaces__msg__DroneState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // timestamp
  if (lhs->timestamp != rhs->timestamp) {
    return false;
  }
  // position_timestamp
  if (lhs->position_timestamp != rhs->position_timestamp) {
    return false;
  }
  // position
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->position), &(rhs->position)))
  {
    return false;
  }
  // velocity_timestamp
  if (lhs->velocity_timestamp != rhs->velocity_timestamp) {
    return false;
  }
  // velocity
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->velocity), &(rhs->velocity)))
  {
    return false;
  }
  // orientation
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->orientation), &(rhs->orientation)))
  {
    return false;
  }
  // target_position
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->target_position), &(rhs->target_position)))
  {
    return false;
  }
  // acceleration
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->acceleration), &(rhs->acceleration)))
  {
    return false;
  }
  // battery_state_timestamp
  if (lhs->battery_state_timestamp != rhs->battery_state_timestamp) {
    return false;
  }
  // battery_voltage
  if (lhs->battery_voltage != rhs->battery_voltage) {
    return false;
  }
  // battery_current
  if (lhs->battery_current != rhs->battery_current) {
    return false;
  }
  // battery_percentage
  if (lhs->battery_percentage != rhs->battery_percentage) {
    return false;
  }
  // battery_discharged_mah
  if (lhs->battery_discharged_mah != rhs->battery_discharged_mah) {
    return false;
  }
  // battery_average_current
  if (lhs->battery_average_current != rhs->battery_average_current) {
    return false;
  }
  // actuator_speeds
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->actuator_speeds), &(rhs->actuator_speeds)))
  {
    return false;
  }
  // arming_state
  if (lhs->arming_state != rhs->arming_state) {
    return false;
  }
  // trajectory_mode
  if (lhs->trajectory_mode != rhs->trajectory_mode) {
    return false;
  }
  // estop
  if (lhs->estop != rhs->estop) {
    return false;
  }
  // flight_mode
  if (lhs->flight_mode != rhs->flight_mode) {
    return false;
  }
  // flight_time
  if (lhs->flight_time != rhs->flight_time) {
    return false;
  }
  return true;
}

bool
interfaces__msg__DroneState__copy(
  const interfaces__msg__DroneState * input,
  interfaces__msg__DroneState * output)
{
  if (!input || !output) {
    return false;
  }
  // timestamp
  output->timestamp = input->timestamp;
  // position_timestamp
  output->position_timestamp = input->position_timestamp;
  // position
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->position), &(output->position)))
  {
    return false;
  }
  // velocity_timestamp
  output->velocity_timestamp = input->velocity_timestamp;
  // velocity
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->velocity), &(output->velocity)))
  {
    return false;
  }
  // orientation
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->orientation), &(output->orientation)))
  {
    return false;
  }
  // target_position
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->target_position), &(output->target_position)))
  {
    return false;
  }
  // acceleration
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->acceleration), &(output->acceleration)))
  {
    return false;
  }
  // battery_state_timestamp
  output->battery_state_timestamp = input->battery_state_timestamp;
  // battery_voltage
  output->battery_voltage = input->battery_voltage;
  // battery_current
  output->battery_current = input->battery_current;
  // battery_percentage
  output->battery_percentage = input->battery_percentage;
  // battery_discharged_mah
  output->battery_discharged_mah = input->battery_discharged_mah;
  // battery_average_current
  output->battery_average_current = input->battery_average_current;
  // actuator_speeds
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->actuator_speeds), &(output->actuator_speeds)))
  {
    return false;
  }
  // arming_state
  output->arming_state = input->arming_state;
  // trajectory_mode
  output->trajectory_mode = input->trajectory_mode;
  // estop
  output->estop = input->estop;
  // flight_mode
  output->flight_mode = input->flight_mode;
  // flight_time
  output->flight_time = input->flight_time;
  return true;
}

interfaces__msg__DroneState *
interfaces__msg__DroneState__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces__msg__DroneState * msg = (interfaces__msg__DroneState *)allocator.allocate(sizeof(interfaces__msg__DroneState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(interfaces__msg__DroneState));
  bool success = interfaces__msg__DroneState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
interfaces__msg__DroneState__destroy(interfaces__msg__DroneState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    interfaces__msg__DroneState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
interfaces__msg__DroneState__Sequence__init(interfaces__msg__DroneState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces__msg__DroneState * data = NULL;

  if (size) {
    data = (interfaces__msg__DroneState *)allocator.zero_allocate(size, sizeof(interfaces__msg__DroneState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = interfaces__msg__DroneState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        interfaces__msg__DroneState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
interfaces__msg__DroneState__Sequence__fini(interfaces__msg__DroneState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      interfaces__msg__DroneState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

interfaces__msg__DroneState__Sequence *
interfaces__msg__DroneState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces__msg__DroneState__Sequence * array = (interfaces__msg__DroneState__Sequence *)allocator.allocate(sizeof(interfaces__msg__DroneState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = interfaces__msg__DroneState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
interfaces__msg__DroneState__Sequence__destroy(interfaces__msg__DroneState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    interfaces__msg__DroneState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
interfaces__msg__DroneState__Sequence__are_equal(const interfaces__msg__DroneState__Sequence * lhs, const interfaces__msg__DroneState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!interfaces__msg__DroneState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
interfaces__msg__DroneState__Sequence__copy(
  const interfaces__msg__DroneState__Sequence * input,
  interfaces__msg__DroneState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(interfaces__msg__DroneState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    interfaces__msg__DroneState * data =
      (interfaces__msg__DroneState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!interfaces__msg__DroneState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          interfaces__msg__DroneState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!interfaces__msg__DroneState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
