// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice

#include "interfaces/msg/detail/drone_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_interfaces
const rosidl_type_hash_t *
interfaces__msg__DroneState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xfa, 0x3e, 0xf2, 0x7d, 0xe4, 0x60, 0xee, 0xb2,
      0x7b, 0xe1, 0xf8, 0xe6, 0x63, 0x8b, 0x00, 0x0d,
      0xce, 0xef, 0x0d, 0x71, 0x1d, 0x59, 0xfc, 0xfa,
      0xda, 0xd9, 0xd1, 0x55, 0xf9, 0xf4, 0xb7, 0x2e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char interfaces__msg__DroneState__TYPE_NAME[] = "interfaces/msg/DroneState";

// Define type names, field names, and default values
static char interfaces__msg__DroneState__FIELD_NAME__timestamp[] = "timestamp";
static char interfaces__msg__DroneState__FIELD_NAME__position_timestamp[] = "position_timestamp";
static char interfaces__msg__DroneState__FIELD_NAME__position[] = "position";
static char interfaces__msg__DroneState__FIELD_NAME__velocity_timestamp[] = "velocity_timestamp";
static char interfaces__msg__DroneState__FIELD_NAME__velocity[] = "velocity";
static char interfaces__msg__DroneState__FIELD_NAME__orientation[] = "orientation";
static char interfaces__msg__DroneState__FIELD_NAME__target_position[] = "target_position";
static char interfaces__msg__DroneState__FIELD_NAME__acceleration[] = "acceleration";
static char interfaces__msg__DroneState__FIELD_NAME__battery_state_timestamp[] = "battery_state_timestamp";
static char interfaces__msg__DroneState__FIELD_NAME__battery_voltage[] = "battery_voltage";
static char interfaces__msg__DroneState__FIELD_NAME__battery_current[] = "battery_current";
static char interfaces__msg__DroneState__FIELD_NAME__battery_percentage[] = "battery_percentage";
static char interfaces__msg__DroneState__FIELD_NAME__battery_discharged_mah[] = "battery_discharged_mah";
static char interfaces__msg__DroneState__FIELD_NAME__battery_average_current[] = "battery_average_current";
static char interfaces__msg__DroneState__FIELD_NAME__actuator_speeds[] = "actuator_speeds";
static char interfaces__msg__DroneState__FIELD_NAME__arming_state[] = "arming_state";
static char interfaces__msg__DroneState__FIELD_NAME__estop[] = "estop";
static char interfaces__msg__DroneState__FIELD_NAME__flight_mode[] = "flight_mode";

static rosidl_runtime_c__type_description__Field interfaces__msg__DroneState__FIELDS[] = {
  {
    {interfaces__msg__DroneState__FIELD_NAME__timestamp, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__position_timestamp, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__position, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__velocity_timestamp, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__velocity, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__orientation, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__target_position, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__acceleration, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__battery_state_timestamp, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__battery_voltage, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__battery_current, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__battery_percentage, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__battery_discharged_mah, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__battery_average_current, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__actuator_speeds, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__arming_state, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__estop, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__DroneState__FIELD_NAME__flight_mode, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
interfaces__msg__DroneState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {interfaces__msg__DroneState__TYPE_NAME, 25, 25},
      {interfaces__msg__DroneState__FIELDS, 18, 18},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float64 timestamp\n"
  "#int8 id\n"
  "#int8 mode\n"
  "float64 position_timestamp\n"
  "float32[] position #x, y, z\n"
  "float64 velocity_timestamp\n"
  "float32[] velocity #x, y, z\n"
  "float32[] orientation  #roll, pitch, yaw\n"
  "float32[] target_position #x, y, z\n"
  "float32[] acceleration\n"
  "float64 battery_state_timestamp\n"
  "float32 battery_voltage     # in volts\n"
  "float32 battery_current\n"
  "float32 battery_percentage  # 0.0 to 100.0\n"
  "float32 battery_discharged_mah\n"
  "float32 battery_average_current\n"
  "float32[] actuator_speeds #Speed of the four actuators\n"
  "uint8 arming_state  \n"
  "     \n"
  "uint8 estop          \n"
  "int16 flight_mode\n"
  "\n"
  "";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
interfaces__msg__DroneState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {interfaces__msg__DroneState__TYPE_NAME, 25, 25},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 572, 572},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
interfaces__msg__DroneState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *interfaces__msg__DroneState__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
