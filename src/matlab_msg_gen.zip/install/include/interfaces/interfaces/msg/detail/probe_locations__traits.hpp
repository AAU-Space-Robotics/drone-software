// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from interfaces:msg/ProbeLocations.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_locations.hpp"


#ifndef INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__TRAITS_HPP_
#define INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "interfaces/msg/detail/probe_locations__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ProbeLocations & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: num_probes
  {
    out << "num_probes: ";
    rosidl_generator_traits::value_to_yaml(msg.num_probes, out);
    out << ", ";
  }

  // member: classification_confidence
  {
    if (msg.classification_confidence.size() == 0) {
      out << "classification_confidence: []";
    } else {
      out << "classification_confidence: [";
      size_t pending_items = msg.classification_confidence.size();
      for (auto item : msg.classification_confidence) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: probes
  {
    if (msg.probes.size() == 0) {
      out << "probes: []";
    } else {
      out << "probes: [";
      size_t pending_items = msg.probes.size();
      for (auto item : msg.probes) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: centroid_x
  {
    if (msg.centroid_x.size() == 0) {
      out << "centroid_x: []";
    } else {
      out << "centroid_x: [";
      size_t pending_items = msg.centroid_x.size();
      for (auto item : msg.centroid_x) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: centroid_y
  {
    if (msg.centroid_y.size() == 0) {
      out << "centroid_y: []";
    } else {
      out << "centroid_y: [";
      size_t pending_items = msg.centroid_y.size();
      for (auto item : msg.centroid_y) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ProbeLocations & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: num_probes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "num_probes: ";
    rosidl_generator_traits::value_to_yaml(msg.num_probes, out);
    out << "\n";
  }

  // member: classification_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.classification_confidence.size() == 0) {
      out << "classification_confidence: []\n";
    } else {
      out << "classification_confidence:\n";
      for (auto item : msg.classification_confidence) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: probes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.probes.size() == 0) {
      out << "probes: []\n";
    } else {
      out << "probes:\n";
      for (auto item : msg.probes) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: centroid_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.centroid_x.size() == 0) {
      out << "centroid_x: []\n";
    } else {
      out << "centroid_x:\n";
      for (auto item : msg.centroid_x) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: centroid_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.centroid_y.size() == 0) {
      out << "centroid_y: []\n";
    } else {
      out << "centroid_y:\n";
      for (auto item : msg.centroid_y) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ProbeLocations & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace interfaces

namespace rosidl_generator_traits
{

[[deprecated("use interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const interfaces::msg::ProbeLocations & msg,
  std::ostream & out, size_t indentation = 0)
{
  interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const interfaces::msg::ProbeLocations & msg)
{
  return interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<interfaces::msg::ProbeLocations>()
{
  return "interfaces::msg::ProbeLocations";
}

template<>
inline const char * name<interfaces::msg::ProbeLocations>()
{
  return "interfaces/msg/ProbeLocations";
}

template<>
struct has_fixed_size<interfaces::msg::ProbeLocations>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<interfaces::msg::ProbeLocations>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<interfaces::msg::ProbeLocations>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INTERFACES__MSG__DETAIL__PROBE_LOCATIONS__TRAITS_HPP_
