// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from interfaces:msg/ProbeSegmentation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_segmentation.hpp"


#ifndef INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__TRAITS_HPP_
#define INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "interfaces/msg/detail/probe_segmentation__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ProbeSegmentation & msg,
  std::ostream & out)
{
  out << "{";
  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: class_name
  {
    out << "class_name: ";
    rosidl_generator_traits::value_to_yaml(msg.class_name, out);
    out << ", ";
  }

  // member: confidence
  {
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << ", ";
  }

  // member: box
  {
    if (msg.box.size() == 0) {
      out << "box: []";
    } else {
      out << "box: [";
      size_t pending_items = msg.box.size();
      for (auto item : msg.box) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: mask
  {
    if (msg.mask.size() == 0) {
      out << "mask: []";
    } else {
      out << "mask: [";
      size_t pending_items = msg.mask.size();
      for (auto item : msg.mask) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: mask_width
  {
    out << "mask_width: ";
    rosidl_generator_traits::value_to_yaml(msg.mask_width, out);
    out << ", ";
  }

  // member: mask_height
  {
    out << "mask_height: ";
    rosidl_generator_traits::value_to_yaml(msg.mask_height, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ProbeSegmentation & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: class_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "class_name: ";
    rosidl_generator_traits::value_to_yaml(msg.class_name, out);
    out << "\n";
  }

  // member: confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << "\n";
  }

  // member: box
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.box.size() == 0) {
      out << "box: []\n";
    } else {
      out << "box:\n";
      for (auto item : msg.box) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: mask
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.mask.size() == 0) {
      out << "mask: []\n";
    } else {
      out << "mask:\n";
      for (auto item : msg.mask) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: mask_width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mask_width: ";
    rosidl_generator_traits::value_to_yaml(msg.mask_width, out);
    out << "\n";
  }

  // member: mask_height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mask_height: ";
    rosidl_generator_traits::value_to_yaml(msg.mask_height, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ProbeSegmentation & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace interfaces

namespace rosidl_generator_traits
{

[[deprecated("use interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const interfaces::msg::ProbeSegmentation & msg,
  std::ostream & out, size_t indentation = 0)
{
  interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const interfaces::msg::ProbeSegmentation & msg)
{
  return interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<interfaces::msg::ProbeSegmentation>()
{
  return "interfaces::msg::ProbeSegmentation";
}

template<>
inline const char * name<interfaces::msg::ProbeSegmentation>()
{
  return "interfaces/msg/ProbeSegmentation";
}

template<>
struct has_fixed_size<interfaces::msg::ProbeSegmentation>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<interfaces::msg::ProbeSegmentation>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<interfaces::msg::ProbeSegmentation>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INTERFACES__MSG__DETAIL__PROBE_SEGMENTATION__TRAITS_HPP_
