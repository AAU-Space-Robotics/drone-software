// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from interfaces:msg/DroneCommand.idl
// generated code does not contain a copyright notice
#include "interfaces/msg/detail/drone_command__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
interfaces__msg__DroneCommand__init(interfaces__msg__DroneCommand * msg)
{
  if (!msg) {
    return false;
  }
  // timestamp
  // cmd_estop
  // cmd_eland
  // identifier
  // cmd_arm
  // cmd_mode
  // cmd_roll
  // cmd_pitch
  // cmd_yaw
  // cmd_thrust
  // cmd_auto_roll
  // cmd_auto_pitch
  // cmd_auto_yaw
  // cmd_auto_thrust
  // cmd_auto_disarm
  return true;
}

void
interfaces__msg__DroneCommand__fini(interfaces__msg__DroneCommand * msg)
{
  if (!msg) {
    return;
  }
  // timestamp
  // cmd_estop
  // cmd_eland
  // identifier
  // cmd_arm
  // cmd_mode
  // cmd_roll
  // cmd_pitch
  // cmd_yaw
  // cmd_thrust
  // cmd_auto_roll
  // cmd_auto_pitch
  // cmd_auto_yaw
  // cmd_auto_thrust
  // cmd_auto_disarm
}

bool
interfaces__msg__DroneCommand__are_equal(const interfaces__msg__DroneCommand * lhs, const interfaces__msg__DroneCommand * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // timestamp
  if (lhs->timestamp != rhs->timestamp) {
    return false;
  }
  // cmd_estop
  if (lhs->cmd_estop != rhs->cmd_estop) {
    return false;
  }
  // cmd_eland
  if (lhs->cmd_eland != rhs->cmd_eland) {
    return false;
  }
  // identifier
  if (lhs->identifier != rhs->identifier) {
    return false;
  }
  // cmd_arm
  if (lhs->cmd_arm != rhs->cmd_arm) {
    return false;
  }
  // cmd_mode
  if (lhs->cmd_mode != rhs->cmd_mode) {
    return false;
  }
  // cmd_roll
  if (lhs->cmd_roll != rhs->cmd_roll) {
    return false;
  }
  // cmd_pitch
  if (lhs->cmd_pitch != rhs->cmd_pitch) {
    return false;
  }
  // cmd_yaw
  if (lhs->cmd_yaw != rhs->cmd_yaw) {
    return false;
  }
  // cmd_thrust
  if (lhs->cmd_thrust != rhs->cmd_thrust) {
    return false;
  }
  // cmd_auto_roll
  if (lhs->cmd_auto_roll != rhs->cmd_auto_roll) {
    return false;
  }
  // cmd_auto_pitch
  if (lhs->cmd_auto_pitch != rhs->cmd_auto_pitch) {
    return false;
  }
  // cmd_auto_yaw
  if (lhs->cmd_auto_yaw != rhs->cmd_auto_yaw) {
    return false;
  }
  // cmd_auto_thrust
  if (lhs->cmd_auto_thrust != rhs->cmd_auto_thrust) {
    return false;
  }
  // cmd_auto_disarm
  if (lhs->cmd_auto_disarm != rhs->cmd_auto_disarm) {
    return false;
  }
  return true;
}

bool
interfaces__msg__DroneCommand__copy(
  const interfaces__msg__DroneCommand * input,
  interfaces__msg__DroneCommand * output)
{
  if (!input || !output) {
    return false;
  }
  // timestamp
  output->timestamp = input->timestamp;
  // cmd_estop
  output->cmd_estop = input->cmd_estop;
  // cmd_eland
  output->cmd_eland = input->cmd_eland;
  // identifier
  output->identifier = input->identifier;
  // cmd_arm
  output->cmd_arm = input->cmd_arm;
  // cmd_mode
  output->cmd_mode = input->cmd_mode;
  // cmd_roll
  output->cmd_roll = input->cmd_roll;
  // cmd_pitch
  output->cmd_pitch = input->cmd_pitch;
  // cmd_yaw
  output->cmd_yaw = input->cmd_yaw;
  // cmd_thrust
  output->cmd_thrust = input->cmd_thrust;
  // cmd_auto_roll
  output->cmd_auto_roll = input->cmd_auto_roll;
  // cmd_auto_pitch
  output->cmd_auto_pitch = input->cmd_auto_pitch;
  // cmd_auto_yaw
  output->cmd_auto_yaw = input->cmd_auto_yaw;
  // cmd_auto_thrust
  output->cmd_auto_thrust = input->cmd_auto_thrust;
  // cmd_auto_disarm
  output->cmd_auto_disarm = input->cmd_auto_disarm;
  return true;
}

interfaces__msg__DroneCommand *
interfaces__msg__DroneCommand__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces__msg__DroneCommand * msg = (interfaces__msg__DroneCommand *)allocator.allocate(sizeof(interfaces__msg__DroneCommand), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(interfaces__msg__DroneCommand));
  bool success = interfaces__msg__DroneCommand__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
interfaces__msg__DroneCommand__destroy(interfaces__msg__DroneCommand * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    interfaces__msg__DroneCommand__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
interfaces__msg__DroneCommand__Sequence__init(interfaces__msg__DroneCommand__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces__msg__DroneCommand * data = NULL;

  if (size) {
    data = (interfaces__msg__DroneCommand *)allocator.zero_allocate(size, sizeof(interfaces__msg__DroneCommand), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = interfaces__msg__DroneCommand__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        interfaces__msg__DroneCommand__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
interfaces__msg__DroneCommand__Sequence__fini(interfaces__msg__DroneCommand__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      interfaces__msg__DroneCommand__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

interfaces__msg__DroneCommand__Sequence *
interfaces__msg__DroneCommand__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces__msg__DroneCommand__Sequence * array = (interfaces__msg__DroneCommand__Sequence *)allocator.allocate(sizeof(interfaces__msg__DroneCommand__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = interfaces__msg__DroneCommand__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
interfaces__msg__DroneCommand__Sequence__destroy(interfaces__msg__DroneCommand__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    interfaces__msg__DroneCommand__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
interfaces__msg__DroneCommand__Sequence__are_equal(const interfaces__msg__DroneCommand__Sequence * lhs, const interfaces__msg__DroneCommand__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!interfaces__msg__DroneCommand__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
interfaces__msg__DroneCommand__Sequence__copy(
  const interfaces__msg__DroneCommand__Sequence * input,
  interfaces__msg__DroneCommand__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(interfaces__msg__DroneCommand);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    interfaces__msg__DroneCommand * data =
      (interfaces__msg__DroneCommand *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!interfaces__msg__DroneCommand__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          interfaces__msg__DroneCommand__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!interfaces__msg__DroneCommand__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
