// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/ProbeGlobalLocations.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_global_locations.h"


#ifndef INTERFACES__MSG__DETAIL__PROBE_GLOBAL_LOCATIONS__STRUCT_H_
#define INTERFACES__MSG__DETAIL__PROBE_GLOBAL_LOCATIONS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'x'
// Member 'y'
// Member 'z'
// Member 'confidence'
// Member 'contribution'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/ProbeGlobalLocations in the package interfaces.
/**
  * ProbeGlobalLocations.msg
 */
typedef struct interfaces__msg__ProbeGlobalLocations
{
  /// List of averaged x, y, z positions for each probe
  rosidl_runtime_c__float__Sequence x;
  rosidl_runtime_c__float__Sequence y;
  rosidl_runtime_c__float__Sequence z;
  /// List of average confidence values
  rosidl_runtime_c__float__Sequence confidence;
  /// Number of detections that contributed to each probe
  rosidl_runtime_c__int32__Sequence contribution;
  /// amount of probes
  int32_t probe_count;
  /// Timestamp of the message
  builtin_interfaces__msg__Time stamp;
} interfaces__msg__ProbeGlobalLocations;

// Struct for a sequence of interfaces__msg__ProbeGlobalLocations.
typedef struct interfaces__msg__ProbeGlobalLocations__Sequence
{
  interfaces__msg__ProbeGlobalLocations * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__ProbeGlobalLocations__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__PROBE_GLOBAL_LOCATIONS__STRUCT_H_
