// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/ManualControlInput.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/manual_control_input.hpp"


#ifndef INTERFACES__MSG__DETAIL__MANUAL_CONTROL_INPUT__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__MANUAL_CONTROL_INPUT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/manual_control_input__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_ManualControlInput_selfdestruct
{
public:
  explicit Init_ManualControlInput_selfdestruct(::interfaces::msg::ManualControlInput & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::ManualControlInput selfdestruct(::interfaces::msg::ManualControlInput::_selfdestruct_type arg)
  {
    msg_.selfdestruct = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

class Init_ManualControlInput_estop
{
public:
  explicit Init_ManualControlInput_estop(::interfaces::msg::ManualControlInput & msg)
  : msg_(msg)
  {}
  Init_ManualControlInput_selfdestruct estop(::interfaces::msg::ManualControlInput::_estop_type arg)
  {
    msg_.estop = std::move(arg);
    return Init_ManualControlInput_selfdestruct(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

class Init_ManualControlInput_arm
{
public:
  explicit Init_ManualControlInput_arm(::interfaces::msg::ManualControlInput & msg)
  : msg_(msg)
  {}
  Init_ManualControlInput_estop arm(::interfaces::msg::ManualControlInput::_arm_type arg)
  {
    msg_.arm = std::move(arg);
    return Init_ManualControlInput_estop(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

class Init_ManualControlInput_thrust
{
public:
  explicit Init_ManualControlInput_thrust(::interfaces::msg::ManualControlInput & msg)
  : msg_(msg)
  {}
  Init_ManualControlInput_arm thrust(::interfaces::msg::ManualControlInput::_thrust_type arg)
  {
    msg_.thrust = std::move(arg);
    return Init_ManualControlInput_arm(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

class Init_ManualControlInput_yaw_velocity
{
public:
  explicit Init_ManualControlInput_yaw_velocity(::interfaces::msg::ManualControlInput & msg)
  : msg_(msg)
  {}
  Init_ManualControlInput_thrust yaw_velocity(::interfaces::msg::ManualControlInput::_yaw_velocity_type arg)
  {
    msg_.yaw_velocity = std::move(arg);
    return Init_ManualControlInput_thrust(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

class Init_ManualControlInput_pitch
{
public:
  explicit Init_ManualControlInput_pitch(::interfaces::msg::ManualControlInput & msg)
  : msg_(msg)
  {}
  Init_ManualControlInput_yaw_velocity pitch(::interfaces::msg::ManualControlInput::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_ManualControlInput_yaw_velocity(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

class Init_ManualControlInput_roll
{
public:
  Init_ManualControlInput_roll()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ManualControlInput_pitch roll(::interfaces::msg::ManualControlInput::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_ManualControlInput_pitch(msg_);
  }

private:
  ::interfaces::msg::ManualControlInput msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::ManualControlInput>()
{
  return interfaces::msg::builder::Init_ManualControlInput_roll();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__MANUAL_CONTROL_INPUT__BUILDER_HPP_
