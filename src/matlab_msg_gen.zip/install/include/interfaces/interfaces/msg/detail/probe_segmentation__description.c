// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from interfaces:msg/ProbeSegmentation.idl
// generated code does not contain a copyright notice

#include "interfaces/msg/detail/probe_segmentation__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_interfaces
const rosidl_type_hash_t *
interfaces__msg__ProbeSegmentation__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x46, 0xf5, 0xab, 0x60, 0xe2, 0xcb, 0x22, 0xc2,
      0xcb, 0xae, 0xe2, 0xee, 0xf7, 0xc8, 0x1f, 0x10,
      0xcd, 0xe4, 0xc6, 0x2e, 0x0b, 0x74, 0x32, 0x34,
      0x20, 0x36, 0x04, 0xee, 0x88, 0x1a, 0xe3, 0x7a,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char interfaces__msg__ProbeSegmentation__TYPE_NAME[] = "interfaces/msg/ProbeSegmentation";

// Define type names, field names, and default values
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__id[] = "id";
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__class_name[] = "class_name";
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__confidence[] = "confidence";
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__box[] = "box";
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__mask[] = "mask";
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__mask_width[] = "mask_width";
static char interfaces__msg__ProbeSegmentation__FIELD_NAME__mask_height[] = "mask_height";

static rosidl_runtime_c__type_description__Field interfaces__msg__ProbeSegmentation__FIELDS[] = {
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__id, 2, 2},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__class_name, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__confidence, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__box, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__mask, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__mask_width, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {interfaces__msg__ProbeSegmentation__FIELD_NAME__mask_height, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
interfaces__msg__ProbeSegmentation__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {interfaces__msg__ProbeSegmentation__TYPE_NAME, 32, 32},
      {interfaces__msg__ProbeSegmentation__FIELDS, 7, 7},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# ProbeSegmentation.msg\n"
  "uint32 id                  # Detection ID\n"
  "string class_name         # Class name of detected object\n"
  "float32 confidence        # Confidence score\n"
  "float32[] box             # Bounding box [x_min, y_min, x_max, y_max]\n"
  "float32[] mask            # Flattened segmentation mask points\n"
  "uint32 mask_width         # Width of original mask\n"
  "uint32 mask_height        # Height of original mask";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
interfaces__msg__ProbeSegmentation__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {interfaces__msg__ProbeSegmentation__TYPE_NAME, 32, 32},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 404, 404},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
interfaces__msg__ProbeSegmentation__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *interfaces__msg__ProbeSegmentation__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
