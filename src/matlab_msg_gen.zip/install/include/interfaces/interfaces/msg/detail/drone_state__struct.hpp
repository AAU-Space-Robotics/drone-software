// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/DroneState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/drone_state.hpp"


#ifndef INTERFACES__MSG__DETAIL__DRONE_STATE__STRUCT_HPP_
#define INTERFACES__MSG__DETAIL__DRONE_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__interfaces__msg__DroneState __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__DroneState __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DroneState_
{
  using Type = DroneState_<ContainerAllocator>;

  explicit DroneState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->timestamp = 0.0;
      this->position_timestamp = 0.0;
      this->velocity_timestamp = 0.0;
      this->battery_state_timestamp = 0.0;
      this->battery_voltage = 0.0f;
      this->battery_current = 0.0f;
      this->battery_percentage = 0.0f;
      this->battery_discharged_mah = 0.0f;
      this->battery_average_current = 0.0f;
      this->arming_state = 0;
      this->estop = 0;
      this->flight_mode = 0;
    }
  }

  explicit DroneState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->timestamp = 0.0;
      this->position_timestamp = 0.0;
      this->velocity_timestamp = 0.0;
      this->battery_state_timestamp = 0.0;
      this->battery_voltage = 0.0f;
      this->battery_current = 0.0f;
      this->battery_percentage = 0.0f;
      this->battery_discharged_mah = 0.0f;
      this->battery_average_current = 0.0f;
      this->arming_state = 0;
      this->estop = 0;
      this->flight_mode = 0;
    }
  }

  // field types and members
  using _timestamp_type =
    double;
  _timestamp_type timestamp;
  using _position_timestamp_type =
    double;
  _position_timestamp_type position_timestamp;
  using _position_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _position_type position;
  using _velocity_timestamp_type =
    double;
  _velocity_timestamp_type velocity_timestamp;
  using _velocity_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _velocity_type velocity;
  using _orientation_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _orientation_type orientation;
  using _target_position_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _target_position_type target_position;
  using _acceleration_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _acceleration_type acceleration;
  using _battery_state_timestamp_type =
    double;
  _battery_state_timestamp_type battery_state_timestamp;
  using _battery_voltage_type =
    float;
  _battery_voltage_type battery_voltage;
  using _battery_current_type =
    float;
  _battery_current_type battery_current;
  using _battery_percentage_type =
    float;
  _battery_percentage_type battery_percentage;
  using _battery_discharged_mah_type =
    float;
  _battery_discharged_mah_type battery_discharged_mah;
  using _battery_average_current_type =
    float;
  _battery_average_current_type battery_average_current;
  using _actuator_speeds_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _actuator_speeds_type actuator_speeds;
  using _arming_state_type =
    uint8_t;
  _arming_state_type arming_state;
  using _estop_type =
    uint8_t;
  _estop_type estop;
  using _flight_mode_type =
    int16_t;
  _flight_mode_type flight_mode;

  // setters for named parameter idiom
  Type & set__timestamp(
    const double & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__position_timestamp(
    const double & _arg)
  {
    this->position_timestamp = _arg;
    return *this;
  }
  Type & set__position(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->position = _arg;
    return *this;
  }
  Type & set__velocity_timestamp(
    const double & _arg)
  {
    this->velocity_timestamp = _arg;
    return *this;
  }
  Type & set__velocity(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__orientation(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->orientation = _arg;
    return *this;
  }
  Type & set__target_position(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->target_position = _arg;
    return *this;
  }
  Type & set__acceleration(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->acceleration = _arg;
    return *this;
  }
  Type & set__battery_state_timestamp(
    const double & _arg)
  {
    this->battery_state_timestamp = _arg;
    return *this;
  }
  Type & set__battery_voltage(
    const float & _arg)
  {
    this->battery_voltage = _arg;
    return *this;
  }
  Type & set__battery_current(
    const float & _arg)
  {
    this->battery_current = _arg;
    return *this;
  }
  Type & set__battery_percentage(
    const float & _arg)
  {
    this->battery_percentage = _arg;
    return *this;
  }
  Type & set__battery_discharged_mah(
    const float & _arg)
  {
    this->battery_discharged_mah = _arg;
    return *this;
  }
  Type & set__battery_average_current(
    const float & _arg)
  {
    this->battery_average_current = _arg;
    return *this;
  }
  Type & set__actuator_speeds(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->actuator_speeds = _arg;
    return *this;
  }
  Type & set__arming_state(
    const uint8_t & _arg)
  {
    this->arming_state = _arg;
    return *this;
  }
  Type & set__estop(
    const uint8_t & _arg)
  {
    this->estop = _arg;
    return *this;
  }
  Type & set__flight_mode(
    const int16_t & _arg)
  {
    this->flight_mode = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::DroneState_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::DroneState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::DroneState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::DroneState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::DroneState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::DroneState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::DroneState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::DroneState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::DroneState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::DroneState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__DroneState
    std::shared_ptr<interfaces::msg::DroneState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__DroneState
    std::shared_ptr<interfaces::msg::DroneState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DroneState_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->position_timestamp != other.position_timestamp) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    if (this->velocity_timestamp != other.velocity_timestamp) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->orientation != other.orientation) {
      return false;
    }
    if (this->target_position != other.target_position) {
      return false;
    }
    if (this->acceleration != other.acceleration) {
      return false;
    }
    if (this->battery_state_timestamp != other.battery_state_timestamp) {
      return false;
    }
    if (this->battery_voltage != other.battery_voltage) {
      return false;
    }
    if (this->battery_current != other.battery_current) {
      return false;
    }
    if (this->battery_percentage != other.battery_percentage) {
      return false;
    }
    if (this->battery_discharged_mah != other.battery_discharged_mah) {
      return false;
    }
    if (this->battery_average_current != other.battery_average_current) {
      return false;
    }
    if (this->actuator_speeds != other.actuator_speeds) {
      return false;
    }
    if (this->arming_state != other.arming_state) {
      return false;
    }
    if (this->estop != other.estop) {
      return false;
    }
    if (this->flight_mode != other.flight_mode) {
      return false;
    }
    return true;
  }
  bool operator!=(const DroneState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DroneState_

// alias to use template instance with default allocator
using DroneState =
  interfaces::msg::DroneState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__DRONE_STATE__STRUCT_HPP_
