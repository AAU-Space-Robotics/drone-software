// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/MotionCapturePose.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/motion_capture_pose.h"


#ifndef INTERFACES__MSG__DETAIL__MOTION_CAPTURE_POSE__STRUCT_H_
#define INTERFACES__MSG__DETAIL__MOTION_CAPTURE_POSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/MotionCapturePose in the package interfaces.
/**
  * MotionCapturePose.msg
 */
typedef struct interfaces__msg__MotionCapturePose
{
  double timestamp;
  double x;
  double y;
  double z;
  double roll;
  double pitch;
  double yaw;
} interfaces__msg__MotionCapturePose;

// Struct for a sequence of interfaces__msg__MotionCapturePose.
typedef struct interfaces__msg__MotionCapturePose__Sequence
{
  interfaces__msg__MotionCapturePose * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__MotionCapturePose__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__DETAIL__MOTION_CAPTURE_POSE__STRUCT_H_
