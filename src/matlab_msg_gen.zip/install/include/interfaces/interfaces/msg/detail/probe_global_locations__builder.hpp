// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/ProbeGlobalLocations.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "interfaces/msg/probe_global_locations.hpp"


#ifndef INTERFACES__MSG__DETAIL__PROBE_GLOBAL_LOCATIONS__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__PROBE_GLOBAL_LOCATIONS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/probe_global_locations__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_ProbeGlobalLocations_stamp
{
public:
  explicit Init_ProbeGlobalLocations_stamp(::interfaces::msg::ProbeGlobalLocations & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::ProbeGlobalLocations stamp(::interfaces::msg::ProbeGlobalLocations::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

class Init_ProbeGlobalLocations_probe_count
{
public:
  explicit Init_ProbeGlobalLocations_probe_count(::interfaces::msg::ProbeGlobalLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeGlobalLocations_stamp probe_count(::interfaces::msg::ProbeGlobalLocations::_probe_count_type arg)
  {
    msg_.probe_count = std::move(arg);
    return Init_ProbeGlobalLocations_stamp(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

class Init_ProbeGlobalLocations_contribution
{
public:
  explicit Init_ProbeGlobalLocations_contribution(::interfaces::msg::ProbeGlobalLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeGlobalLocations_probe_count contribution(::interfaces::msg::ProbeGlobalLocations::_contribution_type arg)
  {
    msg_.contribution = std::move(arg);
    return Init_ProbeGlobalLocations_probe_count(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

class Init_ProbeGlobalLocations_confidence
{
public:
  explicit Init_ProbeGlobalLocations_confidence(::interfaces::msg::ProbeGlobalLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeGlobalLocations_contribution confidence(::interfaces::msg::ProbeGlobalLocations::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_ProbeGlobalLocations_contribution(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

class Init_ProbeGlobalLocations_z
{
public:
  explicit Init_ProbeGlobalLocations_z(::interfaces::msg::ProbeGlobalLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeGlobalLocations_confidence z(::interfaces::msg::ProbeGlobalLocations::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_ProbeGlobalLocations_confidence(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

class Init_ProbeGlobalLocations_y
{
public:
  explicit Init_ProbeGlobalLocations_y(::interfaces::msg::ProbeGlobalLocations & msg)
  : msg_(msg)
  {}
  Init_ProbeGlobalLocations_z y(::interfaces::msg::ProbeGlobalLocations::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_ProbeGlobalLocations_z(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

class Init_ProbeGlobalLocations_x
{
public:
  Init_ProbeGlobalLocations_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProbeGlobalLocations_y x(::interfaces::msg::ProbeGlobalLocations::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_ProbeGlobalLocations_y(msg_);
  }

private:
  ::interfaces::msg::ProbeGlobalLocations msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::ProbeGlobalLocations>()
{
  return interfaces::msg::builder::Init_ProbeGlobalLocations_x();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__PROBE_GLOBAL_LOCATIONS__BUILDER_HPP_
