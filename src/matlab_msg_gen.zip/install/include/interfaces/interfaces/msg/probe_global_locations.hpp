// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__PROBE_GLOBAL_LOCATIONS_HPP_
#define INTERFACES__MSG__PROBE_GLOBAL_LOCATIONS_HPP_

#include "interfaces/msg/detail/probe_global_locations__struct.hpp"
#include "interfaces/msg/detail/probe_global_locations__builder.hpp"
#include "interfaces/msg/detail/probe_global_locations__traits.hpp"
#include "interfaces/msg/detail/probe_global_locations__type_support.hpp"

#endif  // INTERFACES__MSG__PROBE_GLOBAL_LOCATIONS_HPP_
