// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DRONE_STATE_HPP_
#define INTERFACES__MSG__DRONE_STATE_HPP_

#include "interfaces/msg/detail/drone_state__struct.hpp"
#include "interfaces/msg/detail/drone_state__builder.hpp"
#include "interfaces/msg/detail/drone_state__traits.hpp"
#include "interfaces/msg/detail/drone_state__type_support.hpp"

#endif  // INTERFACES__MSG__DRONE_STATE_HPP_
